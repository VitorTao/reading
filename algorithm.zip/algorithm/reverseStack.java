package algorithm;

import java.util.Stack;

public class reverseStack {

  public static int getAndRemoveLast(Stack<Integer> stack){
    int res = stack.pop();
    if(!stack.empty()){
      int r = getAndRemoveLast(stack);
      stack.push(res);
      return r;
    }
    return res;
  }

  public static void main(String[] args) {
    Stack<Integer> stack = new Stack<>();
    stack.push(1);
    stack.push(2);
    stack.push(3);
    stack.push(4);
    int s = getAndRemoveLast(stack);
    System.out.println(s);
    System.out.println(stack);
  }
}
