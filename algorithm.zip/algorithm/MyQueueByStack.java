package algorithm;

import java.util.Stack;

public class MyQueueByStack {

  private Stack<Integer> stackpush = new Stack<>();
  private Stack<Integer> stackpoll = new Stack<>();
  public MyQueueByStack() {

  }

  /** Push element x to the back of queue. */
  public void push(int x) {
    stackpush.push(x);
  }

  /** Removes the element from in front of queue and returns that element. */
  public int pop() {
    if(stackpoll.empty()){
      while (!stackpush.empty()){
        stackpoll.push(stackpush.pop());
      }
    }
    return stackpoll.pop();
  }

  /** Get the front element. */
  public int peek() {
    if(stackpoll.empty()){
      while (!stackpush.empty()){
        stackpoll.push(stackpush.pop());
      }
    }
    return stackpoll.peek();
  }

  /** Returns whether the queue is empty. */
  public boolean empty() {
    return stackpoll.empty() && stackpush.empty();
  }
}
