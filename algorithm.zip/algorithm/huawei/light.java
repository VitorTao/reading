package algorithm.huawei;

public class light {
  public static void main(String[] args) {
    int n = 8;
    int[] light = new int[n];
    for (int i = 0; i < n; i++) {
      int l = Math.max(0,100*i-light[i]);
      int r = Math.min((n-1)*100,100*i+light[i]);
//      while ()
    }
  }
}
