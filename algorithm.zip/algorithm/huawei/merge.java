//以数组 intervals 表示若干个区间的集合，其中单个区间为 intervals[i] = [starti, endi] 。请你合并所有重叠的区间，并返
//回 一个不重叠的区间数组，该数组需恰好覆盖输入中的所有区间 。
//
//
//
// 示例 1：
//
//
//输入：intervals = [[1,3],[2,6],[8,10],[15,18]]
//输出：[[1,6],[8,10],[15,18]]
//解释：区间 [1,3] 和 [2,6] 重叠, 将它们合并为 [1,6].
//
//
// 示例 2：
//
//
//输入：intervals = [[1,4],[4,5]]
//输出：[[1,5]]
//解释：区间 [1,4] 和 [4,5] 可被视为重叠区间。
//
//
//
// 提示：
//
//
// 1 <= intervals.length <= 104
// intervals[i].length == 2
// 0 <= starti <= endi <= 104
//
// Related Topics 数组 排序
// 👍 1605 👎 0
package algorithm.huawei;

import java.util.ArrayList;
import java.util.List;

//合并区间 56  先按左边排序   然后比较
public class merge {
  public static int[][] merge(int[][] intervals) {
    int n = intervals.length;
    if (n == 0) return null;
    List<int[]> list = new ArrayList<>();
    for (int i = 0; i < n; i++) {
      for (int j = 1; j < n - i; j++) {
        if (intervals[j][0] < intervals[j - 1][0]) {
          swap(intervals, j, j - 1);
        }
      }
    }
    list.add(intervals[0]);
    for (int i = 1; i < n; i++) {
      int[] arr = list.get(list.size() - 1);
      if (intervals[i][0] > arr[1]) {
        list.add(intervals[i]);
      } else {
        int tmp = Math.max(arr[1], intervals[i][1]);
        int x = arr[0];
        list.remove(list.size() - 1);
        list.add(new int[]{x, tmp});
      }
    }

    return list.toArray(new int[list.size()][]);
  }


  public static int[][] test(int[][] intervals) {
    quicksort(intervals, 0, intervals.length - 1);
    List<int[]> list = new ArrayList<>();
    list.add(new int[]{intervals[0][0], intervals[0][1]});
    for (int i = 1; i < intervals.length; i++) {
      int x = list.get(list.size() - 1)[0];
      int y = list.get(list.size() - 1)[1];
      if (intervals[i][0] <= y && intervals[i][1] > y) {
        y = intervals[i][1];
        list.add(new int[]{x, y});
      }else if(intervals[i][0] > y){
        list.add(new int[]{intervals[i][0], intervals[i][1]});
      }
    }
    int[][] res = new int[list.size()][2];
    for (int i = 0; i < list.size(); i++) {
      res[i] = list.get(i);
    }
    return res;
  }

  public static void quicksort(int[][] intervals, int left, int right) {
    if (left >= right) return;
    int[] base = intervals[left];
    int l = left;
    int r = right;
    while (l < r) {
      while (l < r && base[0] <= intervals[r][0]) {
        r--;
      }
      swap(intervals, l, r);
      while (l < r && base[0] >= intervals[l][0]) {
        l++;
      }
      swap(intervals, l, r);
    }
    intervals[l] = base;
    quicksort(intervals, left, l - 1);
    quicksort(intervals, l + 1, right);
  }

  public static void swap(int[][] intervals, int i, int j) {
    int[] tmp = intervals[i];
    intervals[i] = intervals[j];
    intervals[j] = tmp;
  }

  public static void main(String[] args) {
    int[][] arr = {{1, 3}, {2, 6}, {8, 10}, {15, 18}};
    merge(arr);
  }
}
