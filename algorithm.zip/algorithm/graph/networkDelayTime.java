//有 n 个网络节点，标记为 1 到 n。
//
// 给你一个列表 times，表示信号经过 有向 边的传递时间。 times[i] = (ui, vi, wi)，其中 ui 是源节点，vi 是目标节点， w
//i 是一个信号从源节点传递到目标节点的时间。
//
// 现在，从某个节点 K 发出一个信号。需要多久才能使所有节点都收到信号？如果不能使所有节点收到信号，返回 -1 。
//
//
//
// 示例 1：
//
//
//
//
//输入：times = [[2,1,1],[2,3,1],[3,4,1]], n = 4, k = 2
//输出：2
//
//
// 示例 2：
//
//
//输入：times = [[1,2,1]], n = 2, k = 1
//输出：1
//
//
// 示例 3：
//
//
//输入：times = [[1,2,1]], n = 2, k = 2
//输出：-1
//
//
//
//
// 提示：
//
//
// 1 <= k <= n <= 100
// 1 <= times.length <= 6000
// times[i].length == 3
// 1 <= ui, vi <= n
// ui != vi
// 0 <= wi <= 100
// 所有 (ui, vi) 对都 互不相同（即，不含重复边）
//
// Related Topics 深度优先搜索 广度优先搜索 图 最短路 堆（优先队列）
// 👍 522 👎 0
package algorithm.graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

//从 k 点出发，所有点都被访问到的最短时间」，将问题转换一下其实就是求「从 k 点出发，到其他点 x 的最短距离的最大值」
public class networkDelayTime {
    //    dfs
//    time 记录下从出发点k  到 每个顶点的最短距离
    int[] time;
    List<int[]>[] edge ;
    public int networkDelayTime(int[][] times, int n, int k) {
        time = new int[n + 2];
        edge = new ArrayList[n+1];
        for (int i = 1; i <= n; i++) {
            edge[i] = new ArrayList<>();
            time[i] = 100000000;
        }
        for (int[] i:times) {
            edge[i[0]].add(new int[]{i[1],i[2]});
        }
//        讲道理 k到k 的时间是0
        time[k] = 0;
        dfs(k);
        int ans = 0;
        for (int i = 1; i <= n; i++) {
//            为啥这样结果是对的 原理 假如k 点出发 到所有节点都能到达  那么ans 必然小于初始赋值的100000000 假如有一个到达的节点等于100000000  说明无法到达所有节点
//            所以一开始就从K 出发 遍历 把所有结果存下来 并且存的是到达所有节点的最短时间路径   这其中花费时间最多的就是答案 因为其他路径是并行的 这个最多的跑完 其他也早都到了
            ans = Math.max(time[i], ans);
        }
        return ans == 100000000 ? -1 : ans;
    }

    public void dfs(int k){
//        为什么遍历edge  而不是直接遍历times  因为题目给了初始节点 并且要全部到达  假如从其他节点开始 记录的就不是从初始节点开始的路径了
        for (int[] i:edge[k]) {
            int tmp = time[k] + i[1];
            if(tmp < time[i[0]]){
                time[i[0]] = tmp;
                dfs(i[0]);
            }
        }
    }
//    public int networkDelayTime(int[][] times, int n, int k) {
//        List<int[]>[] edge = new ArrayList[n];
//        Queue<int[]> q = new LinkedBlockingQueue();
//        int[] time = new int[n+1];
//        for (int i = 1; i <= n; i++) {
//            edge[i] = new ArrayList<>();
//            time[i] = 100000000;
//        }
//        for (int[] i:times) {
//            edge[i[0]].add(new int[]{i[1],i[2]});
//        }
////        讲道理 k到k 的时间是0
//        time[k] = 0;
//        q.offer(new int[]{k,0});
//        while (!q.isEmpty()){
//            int[] poll = q.poll();
//            int size = edge[poll[0]].size();
//            for (int i = 0; i < size; i++) {
//                int[] next = edge[poll[0]].get(i);
//                int tmp = poll[1]+next[1];
//                if(time[next[0]]>tmp){
//                    time[next[0]] = tmp;
//                    q.offer(new int[]{next[0],tmp});
//                }
//            }
//        }
//        int ans = 0;
//        for (int i = 1; i <=n; i++) {
////            为啥这样结果是对的 原理 假如k 点出发 到所有节点都能到达  那么ans 必然小于初始赋值的100000000 假如有一个到达的节点等于100000000  说明无法到达所有节点
////            所以一开始就从K 出发 遍历 把所有结果存下来 并且存的是到达所有节点的最短时间路径   这其中花费时间最多的就是答案 因为其他路径是并行的 这个最多的跑完 其他也早都到了
//            ans = Math.max(time[i],ans);
//        }
//        return ans==100000000?-1:ans;
//    }
}
