//有 n 个城市通过一些航班连接。给你一个数组 flights ，其中 flights[i] = [fromi, toi, pricei] ，表示该航班都从城
//市 fromi 开始，以价格 pricei 抵达 toi。
//
// 现在给定所有的城市和航班，以及出发城市 src 和目的地 dst，你的任务是找到出一条最多经过 k 站中转的路线，使得从 src 到 dst 的 价格最便
//宜 ，并返回该价格。 如果不存在这样的路线，则输出 -1。
//
//
//
// 示例 1：
//
//
//输入:
//n = 3, edges = [[0,1,100],[1,2,100],[0,2,500]]
//src = 0, dst = 2, k = 1
//输出: 200
//解释:
//城市航班图如下
//
//
//从城市 0 到城市 2 在 1 站中转以内的最便宜价格是 200，如图中红色所示。
//
// 示例 2：
//
//
//输入:
//n = 3, edges = [[0,1,100],[1,2,100],[0,2,500]]
//src = 0, dst = 2, k = 0
//输出: 500
//解释:
//城市航班图如下
//
//
//从城市 0 到城市 2 在 0 站中转以内的最便宜价格是 500，如图中蓝色所示。
//
//
//
// 提示：
//
//
// 1 <= n <= 100
// 0 <= flights.length <= (n * (n - 1) / 2)
// flights[i].length == 3
// 0 <= fromi, toi < n
// fromi != toi
// 1 <= pricei <= 104
// 航班没有重复，且不存在自环
// 0 <= src, dst, k < n
// src != dst
//
// Related Topics 深度优先搜索 广度优先搜索 图 动态规划 最短路 堆（优先队列）
// 👍 461 👎 0
package algorithm.graph;

import com.fr.third.javax.persistence.criteria.CriteriaBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class findCheapestPrice {
//    dfs  题目说明没有环  要把对应的路径值存储下来  memo
    int[] memo ;
    List<int[]>[] edge;
    public int findCheapestPrice(int n, int[][] flights, int src, int dst, int k) {
//        k 值会超过索引值 所以设大点
        edge = new ArrayList[n+1];
        memo = new int[n+1];
        for (int i = 1; i <= n; i++) {
            edge[i] = new ArrayList<>();
            memo[i] = 100000000;
        }
        for (int[] i:flights) {
            edge[i[0]].add(new int[]{i[1],i[2]});
        }
        memo[src]=0;
        dfs(src,dst,k);
//        为什么一开始k+1 假如k=0 的话 后面程序中的k-1 连一次流程都走不了 ，因为我们要一直遍历到目的地=dst 这样至少要多一次循环，假如 0-1 中转0次
//        那至少走两次循环 到达1 然后判断跟目的地相等 判断返回
//        int res = dfs(src,dst,k+1);
        return memo[dst]==100000000?-1:memo[dst];
    }

    public void dfs(int i, int dst, int k){
//        这句注意 要放在前面  假如k<0  不用管是否跟目的值相同 此时直接返回  因为即使相同 也已经超过中转次数了
        if(k<0)return ;
        for (int[] j:edge[i]) {
            int tmp = memo[i] + j[1];
            if(tmp < memo[j[0]]){
                memo[j[0]] = tmp;
                dfs(j[0],dst,k-1);
            }
        }
    }

    public static void main(String[] args) {
        findCheapestPrice f = new findCheapestPrice();
        int[][] flights = {{0, 1, 1}, {0, 2, 5}, {1, 2, 1}, {2, 3, 1}};
        System.out.println(f.findCheapestPrice(4, flights, 0, 3, 1));
    }
//    int[][] memo ;
//    public int findCheapestPrice(int n, int[][] flights, int src, int dst, int k) {
////        k 值会超过索引值 所以设大点
//        memo = new int[n][n+1];
////        为什么一开始k+1 假如k=0 的话 后面程序中的k-1 连一次流程都走不了 ，因为我们要一直遍历到目的地=dst 这样至少要多一次循环，假如 0-1 中转0次
////        那至少走两次循环 到达1 然后判断跟目的地相等 判断返回
//        int res = dfs(flights,src,dst,k+1);
//        return res==10000000?-1:res;
//    }
//
//    public int dfs(int[][] flights,int i, int dst, int k){
////        这句注意 要放在前面  假如k<0  不用管是否跟目的值相同 此时直接返回  因为即使相同 也已经超过中转次数了
//        if(k<0)return 10000000;
//        if(i==dst)return 0;
//        if(memo[i][dst] != 0)return memo[i][dst];
//        int min = 10000000;
//        for (int[] f:flights) {
//            min = Math.min(min,dfs(flights,f[1],dst,k-1)+f[2]);
//        }
//        memo[i][dst] = min;
//        return min;
//    }
//    public int findCheapestPrice(int n, int[][] flights, int src, int dst, int k) {
////        从src 开始  存储路径 及 当前路径最小值
//        Queue<int[]> q = new LinkedBlockingQueue<>();
////        每条路径初始值  每个点 所有的邻居 及 对应路径值
//        List<int[]>[] edge = new ArrayList[n];
////       从 src 到 某个地方 最优价格  下标既是 目的地
//        int[] price = new int[n];
//        for (int i = 0; i < n; i++) {
//            edge[i] = new ArrayList<>();
//            price[i] = Integer.MAX_VALUE;
//        }
//        for (int[] f:flights){
//            edge[f[0]].add(new int[]{f[1],f[2]});
//        }
////        for (int i = 0; i < edge[src].size(); i++) {
////            int[] e = edge[src].get(i);
////            q.offer(new int[]{e[0],0,e[1]});
////            price[e[0]] = e[1];
////        }
//        q.offer(new int[]{src,0,0});
//        while (!q.isEmpty()){
//            int[] poll = q.poll();
////            注意此边界条件  等于K 的时候还能往下走
//            if(poll[1]>k) continue;
//            int size = edge[poll[0]].size();
//            for (int i = 0; i < size; i++) {
//                int[] next = edge[poll[0]].get(i);
//                int tmp = poll[2]+next[1];
//                if(tmp<price[next[0]]){
//                    price[next[0]] = tmp;
////                    把当前路径放进去 直到超过中转条件 跳出
//                    q.offer(new int[]{next[0],poll[1]+1,tmp});
//                }
//            }
//        }
//        return price[dst]==Integer.MAX_VALUE?-1:price[dst];
//    }
}
