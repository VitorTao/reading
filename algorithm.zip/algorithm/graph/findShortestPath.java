//在一个有 n 个点， m 个边的有向图中，已知每条边长，求出 1 到 n 的最短路径，返回 1 到 n 的最短路径值。如果 1 无法到 n ，输出 -1
//
//  图中可能有重边，无自环。
//
//  数据范围：1 < n \le 5001<n≤500 ， 1 \le m \le 50001≤m≤5000 ， 1 \le dist(n, m) \le 10001≤dist(n,m)≤1000
//  示例1
//  输入：
//  5,5,[[1,2,2],[1,4,5],[2,3,3],[3,5,4],[4,5,5]]
//  复制
//  返回值：
//  9
package algorithm.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class findShortestPath {
  static HashMap<Integer, ArrayList<int[]>> map = new HashMap<Integer, ArrayList<int[]>>();
  static int min = Integer.MAX_VALUE;
  static boolean[] visit ;
  public static int findShortestPath (int n, int m, int[][] graph) {
    // write code here
    ArrayList<int[]> list ;
    visit = new boolean[n+1];
    for(int i=0;i<m;i++){
      int s = graph[i][0];
      int[] tmp = new int[]{graph[i][1],graph[i][2]};
      if(map.containsKey(s)){
        list = map.get(s);
      }else {
        list = new ArrayList<int[]>();
      }
      list.add(tmp);
      map.put(s,list);
    }
    back(1,n,0);
    return min == Integer.MAX_VALUE?-1:min;
  }

  private static void back(int i, int n, int t) {
    if(i==n){
      min = Math.min(min,t);
      return;
    }
    if(visit[i]){
      return;
    }
    visit[i] = true;
    if(!map.containsKey(i)) return;
    ArrayList<int[]> list = map.get(i);
    if(list.isEmpty() || list.size()==0 ) return;
    for (int j = 0; j < list.size(); j++) {
      int[] arr = list.get(j);
      back(arr[0],n,arr[1]+t);
    }
  }
//5,5,[[1,2,2],[1,4,5],[2,3,3],[3,5,4],[4,5,5]]
  public static void main(String[] args) {
//    int[][] arr ={ {1,2,2},{1,4,5},{2,3,3},{3,5,4},{4,5,5}};
//    System.out.println(findShortestPath(5, 5, arr));
    int[][] arr ={{1,2,358},{2,3,106},{2,4,725},{4,5,650},{1,6,780},{6,7,587},{3,8,804},{1,9,252},{3,10,313},{5,3,977},{9,9,132},{7,5,36},{4,5,830},{4,1,713},{2,5,938},{7,5,690},{4,3,896},{9,2,481},{4,6,448},{4,7,888}};
    System.out.println(findShortestPath(10, 20, arr));
  }
}
