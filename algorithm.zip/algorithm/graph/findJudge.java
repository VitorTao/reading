//小镇里有 n 个人，按从 1 到 n 的顺序编号。传言称，这些人中有一个暗地里是小镇法官。
//
// 如果小镇法官真的存在，那么：
//
//
// 小镇法官不会信任任何人。
// 每个人（除了小镇法官）都信任这位小镇法官。
// 只有一个人同时满足属性 1 和属性 2 。
//
//
// 给你一个数组 trust ，其中 trust[i] = [ai, bi] 表示编号为 ai 的人信任编号为 bi 的人。
//
// 如果小镇法官存在并且可以确定他的身份，请返回该法官的编号；否则，返回 -1 。
//
//
//
// 示例 1：
//
//
//输入：n = 2, trust = [[1,2]]
//输出：2
//
//
// 示例 2：
//
//
//输入：n = 3, trust = [[1,3],[2,3]]
//输出：3
//
//
// 示例 3：
//
//
//输入：n = 3, trust = [[1,3],[2,3],[3,1]]
//输出：-1
//
//
//
// 提示：
//
//
// 1 <= n <= 1000
// 0 <= trust.length <= 104
// trust[i].length == 2
// trust 中的所有trust[i] = [ai, bi] 互不相同
// ai != bi
// 1 <= ai, bi <= n
//
// Related Topics 图 数组 哈希表
// 👍 238 👎 0
package algorithm.graph;

import java.util.HashMap;

public class findJudge {

    // 假使一个人是法官 那么他从不给别人投票，收到的票数是n-1个
//    假使一个人不是法官他会给别人投票 虽然存在所有人都给他投票的情况 也可能是n-1票数 此时减去他给别人投的票 也会小于n-1 那么就做一个数组存储每个人得票数
    public int findJudge(int n, int[][] trust) {
        int[] t = new int[n+1];
        for (int[] i:trust) {
            System.out.println(i);
            t[i[1]]++;
            t[i[0]]--;
        }
        for (int i = 1; i <= n; i++) {
            if(t[i]==n-1){
                return i;
            }
        }
        return -1;
    }

//    public int findJudge(int n, int[][] trust) {
//        //记录节点出度数量
//        int[] out = new int[n+1];
//        //记录节点入度数量
//        int[] in = new int[n+1];
//        for(int[] relation : trust){
//            out[relation[0]]++;
//            in[relation[1]]++;
//        }
//        for(int i = 1; i < in.length; ++i){
//            //找到满足条件的就是法官，遍历完没找到则法官不存在返回-1
//            if(out[i] == 0 && in[i] == n-1) return i;
//        }
//        return -1;
//    }

}
