//你这个学期必须选修 numCourses 门课程，记为 0 到 numCourses - 1 。
//
// 在选修某些课程之前需要一些先修课程。 先修课程按数组 prerequisites 给出，其中 prerequisites[i] = [ai, bi] ，表
//示如果要学习课程 ai 则 必须 先学习课程 bi 。
//
//
// 例如，先修课程对 [0, 1] 表示：想要学习课程 0 ，你需要先完成课程 1 。
//
//
// 请你判断是否可能完成所有课程的学习？如果可以，返回 true ；否则，返回 false 。
//
//
//
// 示例 1：
//
//
//输入：numCourses = 2, prerequisites = [[1,0]]
//输出：true
//解释：总共有 2 门课程。学习课程 1 之前，你需要完成课程 0 。这是可能的。
//
// 示例 2：
//
//
//输入：numCourses = 2, prerequisites = [[1,0],[0,1]]
//输出：false
//解释：总共有 2 门课程。学习课程 1 之前，你需要先完成​课程 0 ；并且学习课程 0 之前，你还应先完成课程 1 。这是不可能的。
//
//
//
// 提示：
//
//
// 1 <= numCourses <= 105
// 0 <= prerequisites.length <= 5000
// prerequisites[i].length == 2
// 0 <= ai, bi < numCourses
// prerequisites[i] 中的所有课程对 互不相同
//
// Related Topics 深度优先搜索 广度优先搜索 图 拓扑排序
// 👍 1170 👎 0
package algorithm.graph;

import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;

public class canFinish {
//执行耗时:4 ms,击败了61.80% 的Java  dfs  遍历速度比 bfs 快
//    状态数组 存储每个顶点的状态  当v[i] = 0 未访问 v[i] = 1 本轮已经访问过 说明存在环 返回FALSE
//    v[i] = -1 其他流程已经访问完毕 无需继续 直接返回TRUE
//    int[] v;
//    HashMap<Integer, List<Integer>> maplist = new HashMap<>();
//    public boolean canFinish(int numCourses, int[][] prerequisites) {
//        v = new int[numCourses];
//        for (int i = 0; i < numCourses; i++) {
//            maplist.put(i,new ArrayList<>());
//        }
//        for (int[] i : prerequisites) {
//            maplist.get(i[1]).add(i[0]);
//        }
//        for (int i = 0; i < numCourses; i++) {
//            if(!dfs(i)){
//                return false;
//            }
//        }
//        return true;
//    }
//    public boolean dfs(int i){
//        if(v[i]==-1)return true;
////        当 flag[i] == 1，说明在本轮 DFS 搜索中节点 i 被第2 次访问，即 课程安排图有环
//        if(v[i]==1)return false;
////        这个位置赋值相当于本轮开始
//        v[i] = 1;
//        List<Integer> integers = maplist.get(i);
//        for(int j:integers){
//            if(!dfs(j)){
//                return false;
//            }
//        }
////        这个位置赋值相当于本轮结束
////        当前节点所有邻接节点已被遍历，并没有发现环，则将当前节点 flag 置为 -1
//        v[i]=-1;
//        return true;
//    }

    //    [[1,0],[0,2],[2,1]]  出来拓扑排序   证明是否有环  有向无环图  拓扑排序原理： 对 DAG 的顶点进行排序，使得对每一条有向边
    //(u,v)，均有 u（在排序记录中）比 v 先出现。亦可理解为对某点 v 而言，只有当 v 的所有源点均出现了，v 才能出现。
//    所有节点的入度 初始化 有的入度可能有多个  然后入度为0的进队列 弹出后 相应依赖此节点的度减1  最后没有能入的节点 且 所有入度为0 时 没有环
//    还要储存每个顶点  会有哪些顶点依赖 这样删除入度为0的顶点时 顺便把相应依赖顶点入度减1  numCourses-- 减到0 说明没有环，相当于所有节点都被弹出过并且入度为0
// bfs
    int[] v;
    HashMap<Integer, List<Integer>> maplist = new HashMap<>();
    public boolean canFinish(int numCourses, int[][] prerequisites) {
        v = new int[numCourses];
        for (int i = 0; i < numCourses; i++) {
            maplist.put(i,new ArrayList<>());
        }
        for (int[] i : prerequisites) {
            v[i[0]]++;
            maplist.get(i[1]).add(i[0]);
        }
        Queue<Integer> q = new LinkedBlockingQueue<>();
        for (int i = 0; i < v.length; i++) {
            //                注意 放进去的是i  不是v[i]
            if(v[i]==0)q.offer(i);
        }
        while (!q.isEmpty()){
            numCourses--;
            Integer index = q.poll();
            List<Integer> integers = maplist.get(index);
            for (int i:integers) {
                if(--v[i]==0){
                    //                注意 放进去的是i  不是v[i]
                    q.offer(i);
                }
            }
        }
        return numCourses==0;
    }

}
