package algorithm;

public class Montain {

  public static void main(String[] args) {
    int[] a = new int[]{1,2,3,1};
    System.out.println(5/2);
    int low = 0;
    int high = a.length-1;
    while(low < high){
//      注意索引下标从0开始  左索引+ 后面长度-1
      int mid = low + (high-low)/2;
      if(a[mid] > a[mid+1]){
        high = mid;
      }else{
        low = mid+1;
      }
    }

  }
}
