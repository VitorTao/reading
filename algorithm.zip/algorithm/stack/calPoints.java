package algorithm.stack;

import java.util.Stack;

public class calPoints {
    public int calPoints(String[] ops) {
        Stack<Integer> mod = new Stack<>();
        for (int i = 0; i < ops.length; i++) {
            switch (ops[i]){
                case "+":
                    int f = mod.pop();
                    int t = f+mod.peek();
                    mod.push(f);
                    mod.push(t);
                    break;
                case "D":
                    mod.push(mod.peek()*2);
                    break;
                case "C":
                    mod.pop();
                    break;
                default:
                    mod.push(Integer.valueOf(ops[i]));
                    break;
            }
        }
        int sum = 0;
        while (!mod.empty()){
            sum += mod.pop();
        }
        return sum;
    }
}
