package algorithm.stack;

import algorithm.ListNode;

import java.util.Stack;

public class isPalindrome {
    public boolean isPalindrome(ListNode head) {
        ListNode cur = head;
        Stack<ListNode> stack = new Stack<>();
        while (cur != null){
            stack.push(cur);
            cur = cur.next;
        }
        while(head != null){
            if(head.val != stack.pop().val)return false;
            head = head.next;
        }
        return true;
    }
}
