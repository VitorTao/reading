package algorithm.stack;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class nextGreaterElement {
    public int[] nextGreaterElement(int[] nums1, int[] nums2) {
        int[] res = new int[nums1.length];
        Map<Integer,Integer> map = new HashMap<>();
        Stack<Integer> stack = new Stack<>();
        for (int i = nums2.length-1; i >=0; i--) {
            int j=nums2[i];
            while (!stack.empty() && j > stack.peek()){
                stack.pop();
            }
            map.put(j,stack.empty() ? -1:stack.peek());
            stack.push(j);
        }
        for (int j = 0; j < nums1.length; j++) {
            res[j] = map.get(nums1[j]);
        }
        return res;
    }
//    这个方法最优
//    public int[] nextGreaterElement(int[] nums1, int[] nums2) {
//        int[] res = new int[nums1.length];
//        Map<Integer,Integer> map = new HashMap<>();
//        for (int i = 0; i < nums2.length; i++) {
//            int j=i+1;
//            while (j<nums2.length && nums2[j] <= nums2[i]){
//                j++;
//            }
//            if(j<nums2.length){
//                map.put(nums2[i],nums2[j]);
//            }
//        }
//        for (int j = 0; j < nums1.length; j++) {
//            res[j] = -1;
//            if(map.get(nums1[j])!= null){
//                res[j] = map.get(nums1[j]);
//            }
//        }
//        return res;
//    }
//    public int[] nextGreaterElement(int[] nums1, int[] nums2) {
//        int[] res = new int[nums1.length];
//        for (int i = 0; i < nums1.length; i++) {
//            res[i] = -1;
//            int s = nums2.length-1;
//            for (int j = 0; j < nums2.length; j++) {
//                if(nums1[i] == nums2[j]){
//                    s = j;
//                }
//                if(j>s && nums2[j]>nums1[i]){
//                    res[i] = nums2[j];
//                    break;
//                }
//            }
//        }
//        return res;
//    }
}
