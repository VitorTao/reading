package algorithm.stack;

import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;


public class isValid {

    public static void main(String[] args) {

    }
//()[]{}    {[]}
    public boolean isValid(String s) {
        Map<Character,Character> map = new HashMap<>();
        map.put(')','(');
        map.put('}','{');
        map.put(']','[');
        int length = s.length();
        if(length%2!=0)return false;
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < length; i++) {
            Character isnull = map.get(s.charAt(i));
            if(isnull!=null){
                if(stack.empty() || isnull != stack.pop())return false;
            }else {
                stack.push(s.charAt(i));
            }
        }
        if(!stack.empty()) return false;
        return true;
    }
}
