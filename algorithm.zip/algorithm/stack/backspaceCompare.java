package algorithm.stack;

import java.util.Stack;

public class backspaceCompare {
    public boolean backspaceCompare(String s, String t) {
        return build(s).equals(build(t));
    }

    public String build(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '#') {
                if (sb.length() > 0) {
                    sb.deleteCharAt(sb.length() - 1);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
//    public boolean backspaceCompare(String s, String t) {
//        Stack<Character> stack1 = new Stack<>();
//        Stack<Character> stack2 = new Stack<>();
//        for (int i = 0; i < s.length() || i< t.length(); i++) {
//            if(i<s.length()){
//                char c = s.charAt(i);
//                if(c == '#'&& !stack1.empty()){
//                    stack1.pop();
//                }else if(c!='#') {
//                    stack1.push(c);
//                }
//            }
//            if(i<t.length()){
//                char c = t.charAt(i);
//                if(c == '#'&& !stack2.empty()){
//                    stack2.pop();
//                }else if(c!='#'){
//                    stack2.push(c);
//                }
//            }
//        }
//
//        while (!stack1.empty() || !stack2.empty()){
//            if((stack1.empty() && !stack2.empty()) || (!stack1.empty() && stack2.empty()) || stack1.pop() != stack2.pop()){
//                return false;
//            }
//        }
//        return true;
//    }
}
