package algorithm.stack;

import java.util.Deque;
import java.util.concurrent.LinkedBlockingDeque;

public class MyStackBYQueue1 {
    Deque<Integer> q ;
    public MyStackBYQueue1() {
        q = new LinkedBlockingDeque<>();
    }

    public void push(int x) {
        q.offerFirst(x);
    }

    public int pop() {
        return q.pollFirst();
    }

    public int top() {
        return q.getFirst();
    }

    public boolean empty() {
        return q.isEmpty();
    }
}
