package algorithm.stack;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingDeque;

public class MyStackByQueue {
  private Queue<Integer> poll;
  private Queue<Integer> tmp;

  public MyStackByQueue() {
    poll = new LinkedBlockingDeque<>();
    tmp = new LinkedBlockingDeque<>();
  }

  public void push(int x) {
    while (!poll.isEmpty()) {
      tmp.add(poll.poll());
    }
    poll.add(x);
    while (!tmp.isEmpty()) {
      poll.add(tmp.poll());
    }
  }

  /**
   * Removes the element on top of the stack and returns that element.
   */
  public int pop() {
    return poll.poll();
  }

  /**
   * Get the top element.
   */
  public int top() {
    return poll.peek();
  }

  /**
   * Returns whether the stack is empty.
   */
  public boolean empty() {
    return poll.isEmpty();
  }
  /**
   * Returns whether the stack is empty.
   */
  public static void main(String[] args) {
    Queue<Integer> q = new LinkedBlockingDeque<>();
    q.add(1);
    q.add(2);
    q.add(3);
    q.add(4);
    q.add(5);
//    System.out.println(q.poll());
//    System.out.println(q.poll());
//    System.out.println(q.poll());
    MyStackByQueue myStackByQueue = new MyStackByQueue();
//    myStackByQueue.last();
    System.out.println(q);
  }
}
