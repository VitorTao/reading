package algorithm.stack;

import java.util.Stack;

public class MinStack {
  Stack<Integer> stack = new Stack();
  Stack<Integer> minstack = new Stack();

  public MinStack() {

  }

  public void push(int val) {
    stack.push(val);
    if (!minstack.empty() && minstack.peek() < val) {
      minstack.push(minstack.peek());
      return;
    }
    minstack.push(val);

  }

  public void pop() {
    stack.pop();
    minstack.pop();
  }

  public int top() {
    return stack.peek();
  }

  public int getMin() {
    return minstack.peek();
  }
}
