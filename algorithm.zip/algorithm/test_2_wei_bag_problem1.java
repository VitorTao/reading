package algorithm;

public class test_2_wei_bag_problem1 {
//  空间压缩优化  滚动数组
   public void test_2_wei_bag_problem1(){
    int[] weight = new int[]{1, 3, 4};
    int[] value = new int[]{15, 20, 30};
    int bagWeight = 4;

    int[] dp = new int[bagWeight+1];
    for (int i = 0; i < weight.length; i++) {
      for (int j = 1; j <= bagWeight; j++) {
        if(j-weight[i] >= 0){
          dp[j] = Math.max(dp[j],dp[j-weight[i]]+value[i]) ;
        }
        System.out.println(dp[j]);
      }
    }


    System.out.println(dp[bagWeight]);
  }
//  public void test_2_wei_bag_problem1(){
//    int[] weight = new int[]{1, 3, 4};
//    int[] value = new int[]{15, 20, 30};
//    int bagWeight = 4;
//
//    int[][] dp = new int[weight.length+1][bagWeight+1];
//    for (int i = 0; i < weight.length; i++) {
//      dp[i][0] = 0;
//    }
//    for (int i = bagWeight; i >=weight[0] ; i--) {
//      dp[0][i] = dp[0][i-weight[0]]+value[0] ;
//    }
//    for (int i = 1; i < weight.length; i++) {
//      for (int j = 1; j <= bagWeight; j++) {
//        if(j-weight[i] >= 0){
//          dp[i][j] = Math.max(dp[i-1][j],dp[i-1][j-weight[i]]+value[i]) ;
//        }else{
//          dp[i][j] = dp[i-1][j] ;
//        }
//        System.out.println(dp[i][j]);
//      }
//    }
//    System.out.println(dp[weight.length-1][bagWeight]);
//  }

  public static void main(String[] args) {
//    test_2_wei_bag_problem1 t = new test_2_wei_bag_problem1();
//    t.test_2_wei_bag_problem1();
    String s = "1112";
    System.out.println(s.charAt(0));
  }

}
