//给你一个链表的头节点 head ，旋转链表，将链表每个节点向右移动 k 个位置。
//
//
//
// 示例 1：
//
//
//输入：head = [1,2,3,4,5], k = 2
//输出：[4,5,1,2,3]
//
//
// 示例 2：
//
//
//输入：head = [0,1,2], k = 4
//输出：[2,0,1]
//
//
//
//
// 提示：
//
//
// 链表中节点的数目在范围 [0, 500] 内
// -100 <= Node.val <= 100
// 0 <= k <= 2 * 109
//
// Related Topics 链表 双指针
// 👍 812 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.list;

import algorithm.ListNode;

public class rotateRight {
    public ListNode rotateRight(ListNode head, int k) {
        if(head == null || k == 0) return head;
        ListNode cur = head;
        ListNode pre = null;
        int n = 0;
        while (cur !=null){
            n++;
            pre = cur;
            cur = cur.next;
        }
        int move = (n-1)-(k%n);
//        变成环
        pre.next = head;
        while (move>0){
            head = head.next;
            move--;
        }
        ListNode newhead = head.next;
        head.next = null;
        return newhead;
    }

//    public ListNode rotateRight(ListNode head, int k) {
//        if(k==0 || head ==null) return head;
//        ListNode dummy = new ListNode(-1);
//        dummy.next = head;
//        ListNode cur = head;
//        ListNode pre = dummy;
//        int i=0;
//        while (head != null){
//            i++;
//            head = head.next;
//        }
//        if(k>i){
//            k = k%i;
//        }
//        if(k==0) return dummy.next;
//        System.out.println(k);
//        for (int j = 0; j < k; j++) {
//            cur = cur.next;
//        }
//        while (cur != null){
//            cur = cur.next;
//            pre = pre.next;
//        }
//        ListNode tmp = pre.next;
//        ListNode f = tmp;
//        pre.next = null;
//        while (tmp.next !=null){
//            tmp = tmp.next;
//        }
//        tmp.next = dummy.next;
//        return f;
//    }
    public ListNode dem(ListNode head, int k){
        if(head == null || k == 0) return head;
        ListNode dum = head;
        ListNode pre = null;
        int n = 0;
        while (head!=null){
            pre = head;
            head = head.next;
            n++;
        }
        pre.next = dum;
        while(k>n){
            k = k-n;
        }
        int tmp = n-k;
        while (tmp>0){
            pre = dum;
            dum = dum.next;
            tmp--;
        }
        pre.next =null;
        return dum;
    }
}
