package algorithm.list;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Stack;

public class isPalindrome {
  public boolean isPalindrome(removeElements.ListNode head) {
    HashMap map = new HashMap<>();
    map.put("1",1);
    removeElements.ListNode slow = head;
    removeElements.ListNode fast = head;
    while (fast != null && fast.next != null) {
      slow = slow.next;
      fast = fast.next.next;
    }
    removeElements.ListNode pre = null;
    removeElements.ListNode cur = slow;
    while (cur != null) {
      removeElements.ListNode next = cur.next;
      cur.next = pre;
      pre = cur;
      cur = next;
    }
    while (pre != null) {
      if (pre.val != head.val) {
        return false;
      }
      pre = pre.next;
      head = head.next;
    }
    return true;
  }
//  public boolean isPalindrome(removeElements.ListNode head) {
//    removeElements.ListNode slow = head;
//    removeElements.ListNode fast = head;
//    Stack<removeElements.ListNode> stack = new Stack();
//    while (fast != null && fast.next != null) {
//      slow = slow.next;
//      fast = fast.next.next;
//    }
//    while (slow != null) {
//      stack.push(slow);
//      slow = slow.next;
//    }
//    while (!stack.empty()) {
//      System.out.println(stack.peek().val);
//      if (head.val != stack.peek().val) {
//        return false;
//      }
//      head = head.next;
//      stack.pop();
//    }
//    return true;
//  }
//    public boolean isPalindrome(ListNode head) {
//        ListNode cur = head;
//        Stack<ListNode> stack = new Stack();
//        while (cur != null){
//            stack.push(cur);
//            cur = cur.next;
//        }
//        while (head != null){
//            if(head.val != stack.peek().val){
//                return false;
//            }
//            head = head.next;
//            stack.pop();
//        }
//        return true;
//    }
//    public boolean isPalindrome(ListNode head) {
//        ListNode pre = null;
//        ListNode c = head;
//        ListNode cur = head;
//        while (cur != null){
//            ListNode next = cur.next;
//            cur.next = pre;
//            pre = cur;
//            cur = next;
//        }
//        while (c != null){
//            System.out.println(pre.val);
//            System.out.println(c.val);
//            if(c.val != pre.val){
//                return false;
//            }
//            c = c.next;
//            pre = pre.next;
//        }
//        return true;
//    }
}