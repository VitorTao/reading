package algorithm.list;

import algorithm.ListNode;

public class deleteDuplicatesALL {

    public ListNode deleteDuplicates(ListNode head) {
//        [-1,0,0,0,0,3,3]   [1,1,1,2,3]
        ListNode dummy = new ListNode(head.val-1);
        dummy.next = head;
        ListNode pre = dummy;
        ListNode prev = dummy;
        boolean f = false;
        while (pre != null){
            if(pre.next!=null && pre.next.val == pre.val){
                pre.next = pre.next.next;
                f = true;
                continue;
            }
            if(f){
                prev.next = pre.next;
                f = false;
            }else {
                prev = pre;
            }
            pre = pre.next;
        }
        return dummy.next;
    }
}
