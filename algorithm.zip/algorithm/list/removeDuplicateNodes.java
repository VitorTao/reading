package algorithm.list;

import java.util.HashMap;
import java.util.Map;

public class removeDuplicateNodes {
  public removeElements.ListNode removeDuplicateNodes(removeElements.ListNode head) {
    removeElements.ListNode cur = head;
    removeElements.ListNode pre = head;
    Map<Integer,Integer> map = new HashMap<>();
    while (cur != null){
      if(map.get(cur.val)==null){
        map.put(cur.val,cur.val);
        pre = cur;
      }else{
        pre.next = cur.next;
      }

      cur = cur.next;
    }
    return head;
  }
}
