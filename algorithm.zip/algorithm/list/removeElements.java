package algorithm.list;

public class removeElements {
  public ListNode removeElements(ListNode head, int val) {
    ListNode dump = new ListNode(0);
    dump.next = head;
    ListNode cur = head;
    ListNode pre = dump;
    while (cur != null){
      ListNode next = cur.next;
      if(cur.val == val){
        pre.next = next;
      }else {
        pre = cur;
      }
      cur = next;
    }
    return dump.next;
  }

  public static class ListNode {
      int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }
}
