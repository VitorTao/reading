package algorithm.list;

import algorithm.ListNode;

public class mergeTwoLists {
  public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
    if (list1 == null) return list2;
    if (list2 == null) return list1;
    ListNode dump = new ListNode(-1);
    ListNode prev = dump;
    while (list1 != null && list2 != null) {
      if (list1.val > list2.val) {
        prev.next = list2;
        list2 = list2.next;
      } else  {
        prev.next = list1;
        list1 = list1.next;
      }
      prev = prev.next;
    }
    prev.next = list1==null?list2:list1;
    return dump.next;
  }

//  public removeElements.ListNode mergeTwoLists(removeElements.ListNode l1, removeElements.ListNode l2) {
//    if(l1 == null) return l2;
//    removeElements.ListNode head = new removeElements.ListNode(-1);
//    removeElements.ListNode res = head;
//    while(l1 != null && l2 != null){
//      if(l1.val <= l2.val){
//        head.next = l1;
//        l1 = l1.next;
//      }else if(l1.val > l2.val){
//        head.next = l2;
//        l2 = l2.next;
//      }
//      head = head.next;
//    }
//    if(l1==null){
//      head.next = l2;
//    }
//    if(l2==null){
//      head.next = l1;
//    }
//    return res.next;
//  }
}
