package algorithm.list;

import algorithm.ListNode;

public class swapPairs {

  public ListNode swapPairs(ListNode head) {
    if (head == null || head.next == null) {
      return head;
    }
    ListNode newhead = head.next;
    head.next = swapPairs(newhead.next);
    newhead.next = head;
    return newhead;
  }

  //    public ListNode swapPairs(ListNode head) {
//        ListNode dummy = new ListNode(-1);
//        dummy.next = head;
//        ListNode cur = dummy;
//        while(cur != null && cur.next !=null && cur.next.next != null){
//            ListNode f = cur.next;
//            ListNode s = cur.next.next;
//            ListNode next = s.next;
//            s.next = f;
//            f.next = next;
//            cur.next = s;
//            cur = f;
//        }
//        return dummy.next;
//    }
//public ListNode swapPairs(ListNode head) {
//    ListNode dummyHead = new ListNode(0);
//        dummyHead.next = head;
//        ListNode temp = dummyHead;
//        while (temp.next != null && temp.next.next != null) {
//            ListNode node1 = temp.next;
//            ListNode node2 = temp.next.next;
//            temp.next = node2;
//            node1.next = node2.next;
//            node2.next = node1;
//            temp = node1;
//        }
//        return dummyHead.next;
//}
  public ListNode swapdemo(ListNode head) {
    ListNode dumpy = new ListNode(-1);
    ListNode pre = dumpy;
    while (head != null) {
      ListNode next = head.next;
      ListNode next2 = null;
      if (next != null) {
        next2 = next.next;
        next.next = head;
        pre.next = next;
        pre = head;
//        这一步忘了会死循环
        head.next = null;
        head = next2;
      }else {
        pre.next = head;
        head = null;
      }
    }
    return dumpy.next;
  }

  public static void main(String[] args) {
    System.out.println(2 % 5);
  }
}
