package algorithm.list;

public class detectCycle {
  public removeElements.ListNode detectCycle(removeElements.ListNode head) {
    removeElements.ListNode slow = head;
    removeElements.ListNode fast = head;
    while (slow != null && fast != null && fast.next != null) {
      slow = slow.next;
      fast = fast.next.next;
      if (slow == fast) {
        fast = head;
        while (slow != fast) {
          slow = slow.next;
          fast = fast.next;
        }
        return slow;
      }
    }

    return null;
  }
//  public ListNode detectCycle(ListNode head) {
//    ListNode slow = head;
//    ListNode pre = head;
//    ListNode fast = head;
//    while(fast != null && fast.next != null){
//      slow = slow.next;
//      fast = fast.next.next;
//      if(slow == fast) break;
//    }
//    if(fast==null || fast.next == null) return null;
//    while (pre != slow){
//      pre = pre.next;
//      slow = slow.next;
//    }
//    return pre;
//  }
}
