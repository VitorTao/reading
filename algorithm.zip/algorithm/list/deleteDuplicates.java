package algorithm.list;

import algorithm.ListNode;

import java.util.HashMap;

public class deleteDuplicates {
    public ListNode deleteDuplicates(ListNode head) {

        ListNode pre = head;
        while (pre != null && pre.next != null){
            if(pre.val == pre.next.val){
                pre.next = pre.next.next;
            }else {
                pre = pre.next;
            }

        }
        return head;
    }
//    public ListNode deleteDuplicates(ListNode head) {
//        ListNode dump = new ListNode(-1);
//        ListNode pre = dump;
//        HashMap<Integer,Integer> map = new HashMap<>();
//        while (head != null){
//            if(!map.containsKey(head.val)){
//                pre.next = new ListNode(head.val);
//                pre = pre.next;
//                map.put(head.val,1);
//            }
//            head = head.next;
//        }
//        return dump.next;
//    }

    public static void main(String[] args) {
        ListNode head = new ListNode(1);
        ListNode cur = head;
        int[] a = new int[]{1,2,3,3};
        for (int i = 0; i < a.length; i++) {
            cur.next = new ListNode(a[i]);
            cur = cur.next;
        }
        deleteDuplicates d = new deleteDuplicates();
        ListNode res = d.deleteDuplicates(head);
        while (res != null){
            System.out.println(res.val);
            res = res.next;
        }
    }
}
