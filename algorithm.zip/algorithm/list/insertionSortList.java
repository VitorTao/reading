package algorithm.list;

import algorithm.ListNode;

public class insertionSortList {
    public ListNode insertionSortList(ListNode head) {
        if(head == null || head.next == null)return head;
        ListNode dummy = new ListNode(-1);
        dummy.next = head;
        ListNode cur = head.next;
        ListNode last = head;
        while (cur != null ){
            ListNode next = cur.next;
            if(cur.val < last.val){
                ListNode pre = dummy;
                while (pre.next.val<cur.val){
                    pre = pre.next;
                }
                cur.next = pre.next;
                pre.next = cur;
//                神来之笔  加入新插入的节点不比最后一个大  就需要放到已排好序的列表中间  此时 排好序的最后一个节点仍然链接到新插入节点，导致成环，此时常规做法是断掉最后一个节点与
//                新插入节点的的链接  一般是用last.next = null; 此处神来之笔是last.next = next;  进入下一次循环
                last.next = next;
            }else {
                last = last.next;
            }
            cur = next;
        }
        return dummy.next;
    }
}

