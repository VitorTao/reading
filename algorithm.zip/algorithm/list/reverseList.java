package algorithm.list;

public class reverseList {
  public removeElements.ListNode reverseList(removeElements.ListNode head) {
    removeElements.ListNode pre = null;
    removeElements.ListNode cur = head;
    while (cur != null){
      removeElements.ListNode next = cur.next;
      cur.next = pre;
      pre = cur;
      cur= next;
    }
    return pre;
  }
}
