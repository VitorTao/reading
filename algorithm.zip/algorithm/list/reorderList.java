package algorithm.list;

import algorithm.ListNode;

public class reorderList {

    public void reorderList(ListNode head) {
//        找到中点  反转右链表  合并
        if (head == null || head.next == null || head.next.next == null) return;
        ListNode slow = head;
        ListNode fast = head;
        ListNode cur = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        fast = slow.next;
        slow.next = null;
//        反转
        ListNode pre = null;
        while (fast != null) {
            ListNode next = fast.next;
            fast.next = pre;
            pre = fast;
            fast = next;
        }
        //合并
        while (pre != null){
            ListNode prenext = pre.next;
            ListNode curnext = cur.next;
            cur.next = pre;
            pre.next = curnext;
            cur = curnext;
            pre = prenext;
        }
    }
}