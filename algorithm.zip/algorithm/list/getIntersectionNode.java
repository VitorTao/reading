package algorithm.list;

public class getIntersectionNode {
//  链表 textitheadA  和 textitheadB  的长度分别是 m 和 n。考虑当 m=n 和 mnen  时，两个指针分别会如何移动：
//如果 mnen  ，则由于两个链表没有公共节点，两个指针也不会同时到达两个链表的尾节点，因此两个指针都会遍历完两个链表，在指针 textitpA  移动了 m+n 次、指针 textitpB  移动了 n+m 次之后，两个指针会同时变成空值 textnull  ，此时返回 textnull  。
  public removeElements.ListNode getIntersectionNode(removeElements.ListNode headA, removeElements.ListNode headB) {
    removeElements.ListNode a = headA;
    removeElements.ListNode b = headB;
    while (a != b) {
      a = a == null ? headB : a.next;
      b = b == null ? headA : b.next;
    }
    return a;
  }
}
