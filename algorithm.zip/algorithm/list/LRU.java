package algorithm.list;

import sun.jvmstat.perfdata.monitor.PerfStringVariableMonitor;

import java.util.LinkedHashMap;

public class LRU {
    public static void main(String[] args) {
        LinkedHashMap linkedHashMap = new LinkedHashMap(1);
    }
}
