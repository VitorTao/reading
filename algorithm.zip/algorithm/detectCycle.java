package algorithm;

public class detectCycle {
  public getIntersectionNode.ListNode detectCycle(getIntersectionNode.ListNode head) {
    getIntersectionNode.ListNode slow = head;
    getIntersectionNode.ListNode fast = head;
    while (true){
      if(fast == null || fast.next == null || fast.next.next == null)return null;
      slow = slow.next;
      fast = fast.next.next;
      if(slow==fast)break;
    }
    fast = head;
    while (slow != fast){
      slow = slow.next;
      fast = fast.next;
    }
    return slow;
  }
}
