package algorithm.greedy;

public class largestSumAfterKNegations {
  public int largestSumAfterKNegations(int[] A, int K) {
//        quickSort(A, 0, A.length- 1);
    quicksort(A,0,A.length-1);
//    for (int i = 0; i < A.length-1; i++) {
//      for (int j = i; j < A.length; j++) {
//        if(Math.abs(A[i]) < Math.abs(A[j])){
//          int tmp = A[i];
//          A[i] = A[j];
//          A[j] = tmp;
//        }
//      }
//    }
    for (int i = 0; i < A.length; i++) {
      if(A[i] < 0 && K > 0){
        A[i] *= -1;
        K--;
      }
    }
    int index = A.length-1;
    while (K>0){
      A[index] *= -1;
      K--;
    }
    int sum  = 0;
    for (int i = 0; i < A.length; i++) {
      System.out.println(A[i]);
      sum += A[i];
    }
    return sum;
  }
  
  void quicksort(int[] A,int l,int r){
    int i=l;
    int j=r;
    int base = A[l];
    if(l >= r) return;
    while (l<r){
      while (l<r && A[r] >= base){
        r--;
      }
      A[l] = A[r];
      while (l<r && A[l] <= base){
        l++;
      }
      A[r] = A[l];
    }
    A[l] = base;
    quicksort(A,i,l-1);
    quicksort(A,l+1,j);
  }

  void swap(int[] A,int i,int j){
    int tmp = A[i];
    A[i] = A[j];
    A[j] = tmp;
  }

  public static void main(String[] args) {
    largestSumAfterKNegations s = new largestSumAfterKNegations();
    int[] a = new int[]{3,1,5,4,7,90,2};
    s.quicksort(a,0,a.length-1);
    for (int i = 0; i < a.length; i++) {
      System.out.println(a[i]);
    }

  }
}
