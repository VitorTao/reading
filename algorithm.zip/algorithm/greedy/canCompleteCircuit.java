package algorithm.greedy;

public class canCompleteCircuit {
  public int canCompleteCircuit(int[] gas, int[] cost) {
    int sum = 0;
    int start = 0;
    int i = 0;
    int err = 0;
    while (start < gas.length){
      sum += gas[i]- cost[i];
      start++;
      if(sum < 0){
        err++;
        if(err==gas.length) return -1;
        sum = 0;
        start = 0;
      }
      i++;
      if(i==gas.length){
        i=0;
      }
    }

    return i;
  }
}
