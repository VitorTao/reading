package algorithm.greedy;

import java.util.ArrayList;
import java.util.List;

public class reconstructQueue {
  public int[][] reconstructQueue(int[][] people) {
    List<int[]> q = new ArrayList<>();

    for (int i = 0; i < people.length-1; i++) {
      for (int j = i+1; j < people.length; j++) {
        if(people[i][0] < people[j][0]){
          int[] tmp = people[i];
          people[i] = people[j];
          people[j] = tmp;
        }else if(people[i][0] == people[j][0] && people[i][1] > people[j][1]){
          int[] tmp = people[i];
          people[i] = people[j];
          people[j] = tmp;
        }
      }
    }

    for (int i = 0; i < people.length; i++) {
      q.add(people[i][1], people[i]);
    }
    return q.toArray(new int[q.size()][]);
  }
}
