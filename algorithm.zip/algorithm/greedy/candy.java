package algorithm.greedy;

public class candy {
  public int candy(int[] ratings) {
    int[] dp = new int[ratings.length];
    dp[0]=1;
    for (int i = 1; i < ratings.length; i++) {
      dp[i] = 1;
      if(ratings[i] > ratings[i-1]){
        dp[i] = 1+dp[i-1];
      }
    }
    for (int i = ratings.length-1; i >=1; i--) {
      if(ratings[i-1] > ratings[i] && dp[i-1] <= dp[i]){
        dp[i-1] = dp[i]+1;
      }
    }
    int sum = 0;
    for (int i = 0; i < dp.length; i++) {
      sum+=dp[i];
    }
    return sum;
  }
}
