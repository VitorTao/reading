package algorithm.greedy;

public class findMinArrowShots {
  public int findMinArrowShots(int[][] points) {
    if (points.length == 0) return 0;
    quicksort(points, 0, points.length - 1);
    int s = 1;
    int m = points[0][1];
    for (int i = 1; i < points.length; i++) {
      if (points[i][0] > m) {
        s++;
        m = points[i][1];
      } else {
        m = Math.min(points[i][1], m);
      }
    }

    return s;
  }

  void quicksort(int[][] points, int l, int r) {
    if (l >= r) return;
    int i = l;
    int j = r;
    int base = points[l][0];
    int[] base0 = points[l];
    while (l < r) {
      while (l < r && points[r][0] >= base) {
        r--;
      }
      points[l] = points[r];
      while (l < r && points[l][0] <= base) {
        l++;
      }
      points[r] = points[l];
    }
    points[l] = base0;
    quicksort(points, i, l - 1);
    quicksort(points, l + 1, j);
  }
}
