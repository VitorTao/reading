package algorithm.greedy;

public class canJump {
  public boolean canJump(int[] nums) {
    if(nums.length == 1) return true;
    int n = nums.length;
    int max = 0;
    for (int i = 0; i < n-1; i++) {
      max = Math.max(max,nums[i]+i);
      if(max >= n-1){
        return true;
      }
      if(max <= i && nums[i] == 0){
        return false;
      }
    }
    return false;
  }
}
