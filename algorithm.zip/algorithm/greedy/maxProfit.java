package algorithm.greedy;

public class maxProfit {
  public int maxProfit(int[] prices) {

    int[] dp = new int[prices.length];
    int res = 0;
    for (int i = 1; i < prices.length; i++) {
      dp[i] = prices[i] - prices[i-1];
    }
    for (int i = 0; i < dp.length; i++) {
      if(dp[i] > 0){
        res += dp[i];
      }
    }
    return res;
  }
}
