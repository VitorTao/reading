package algorithm;

public class SortArray {

  public static void main(String[] args) {
    int result = -1;
    int target = 3;
    int[] nums = new int[]{3,1};
    int left = 0;
    int right = nums.length - 1;
    while (left < right) {
      int mid = left + (right - left) / 2;
      if (nums[mid] > nums[right]) {
        left = mid + 1;
      } else if (nums[mid] <= nums[right]) {
        right = mid;
      }
    }
    System.out.println(left);
    int tmpleft = 0;
    int tmpright = nums.length - 1;
    if (target < nums[nums.length - 1]) {
      tmpleft = left;
    } else if (target > nums[nums.length - 1]) {
      if(left > 0){
        tmpright = left - 1;
      }else{
        tmpright = 0 ;
      }
    } else if (target == nums[nums.length - 1]) {
      result = nums.length - 1;
    }
    while (tmpleft <= tmpright) {
      int mid = tmpleft + (tmpright - tmpleft) / 2;
      if (nums[mid] > target) {
        tmpright = mid - 1;
      } else if (nums[mid] < target) {
        tmpleft = mid + 1;
      } else {
        result = mid;
      }
    }
    System.out.println(result);
  }
}
