package algorithm;

public class maxProfit {
  public int maxProfit(int[] prices) {
    if (prices.length == 1) return 0;
    int[] dp = new int[prices.length];
    dp[0] = 0;
    dp[1] = prices[1] - prices[0] > 0 ? prices[1] - prices[0] : 0;
    int min = prices[0] > prices[1] ? prices[1] : prices[0];
    for (int i = 2; i < prices.length; i++) {
      dp[i] = Math.max(dp[i - 1], prices[i] - min);
      if (min > prices[i]) {
        min = prices[i];
      }
    }
    return dp[prices.length - 1];
  }
//  public int maxProfit(int[] prices) {
//    int min = prices[0];
//    int max = 0;
//    for (int i = 1; i < prices.length; i++) {
//      if (prices[i] - min > max) {
//        max = prices[i] - min;
//      }
//      if (min > prices[i]) {
//        min = prices[i];
//      }
//    }
//    return max;
//  }

//    public int maxProfit(int[] prices) {
//        int max = 0;
//        for (int i = 0; i < prices.length-1; i++) {
//            for (int j = i+1; j < prices.length; j++) {
//                if(prices[j]-prices[i] > max){
//                    max = prices[j]-prices[i];
//                }
//            }
//        }
//        return max;
//    }
}
