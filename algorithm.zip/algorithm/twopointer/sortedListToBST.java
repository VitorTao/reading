//给定一个单链表的头节点 head ，其中的元素 按升序排序 ，将其转换为高度平衡的二叉搜索树。
//
// 本题中，一个高度平衡二叉树是指一个二叉树每个节点 的左右两个子树的高度差不超过 1。
//
//
//
// 示例 1:
//
//
//
//
//输入: head = [-10,-3,0,5,9]
//输出: [0,-3,9,-10,null,5]
//解释: 一个可能的答案是[0，-3,9，-10,null,5]，它表示所示的高度平衡的二叉搜索树。
//
//
// 示例 2:
//
//
//输入: head = []
//输出: []
//
//
//
//
// 提示:
//
//
// head 中的节点数在[0, 2 * 104] 范围内
// -105 <= Node.val <= 105
//
// Related Topics 树 二叉搜索树 链表 分治 二叉树
// 👍 684 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.twopointer;


import algorithm.ListNode;
import algorithm.TreeNode;

public class sortedListToBST {
//    双指针 更快  100%
    public TreeNode sortedListToBST(ListNode head) {
        TreeNode res = dfs(head, null);
        return res;
    }

    private TreeNode dfs(ListNode head, ListNode end) {
        if (head == null) return null;
        ListNode fast = head;
        ListNode slow = head;
//        为啥不直接赋值head 或slow 因为它代表前置节点  后面可利用此点判断slow是否有前置节点  没有的话就不用进行左子树循环
        ListNode pre = null;
        while (fast != null && fast.next != null) {
            pre = slow;
            slow = slow.next;
            fast = fast.next.next;
        }
        TreeNode root = new TreeNode(slow.val);
        //   赋值为null 的用意是方便双指针遍历 找中点  并能找到退出条件 否则不好退出递归
        //   这个位置很重要 假如放在slow 赋值前  会把slow的值变为null  切断preSlow和中点slow
        if(pre != null){
            pre.next = null;
            root.left = dfs(head, pre);
        }
        root.right = dfs(slow.next, end);
        return root;
    }
//    public TreeNode sortedListToBST(ListNode head) {
//        List<Integer> arr = new ArrayList<>();
//        while (head!=null){
//            arr.add(head.val);
//            head = head.next;
//        }
//
//        TreeNode res = dfs(arr,0,arr.size()-1);
//        return res;
//    }
//
//    private TreeNode dfs(List<Integer> arr, int s, int e) {
//        if(s>e) return null;
//        int mid = (e+s)/2;
//        TreeNode root = new TreeNode(arr.get(mid));
//        root.left = dfs(arr,s,mid-1);
//        root.right = dfs(arr,mid+1,e);
//        return root;
//    }
}
