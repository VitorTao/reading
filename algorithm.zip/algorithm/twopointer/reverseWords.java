package algorithm.twopointer;

public class reverseWords {
  public String reverseWords(String s) {
    StringBuilder res = new StringBuilder();
    String[] s1 = s.split(" ");
    for (int i = 0; i < s1.length; i++) {
      char[] chars = s1[i].toCharArray();
      int st = 0;
      int e = chars.length-1;
      while (st < e){
        char tmp = chars[st];
        chars[st++] = chars[e];
        chars[e--] = tmp;
      }
      res.append(chars).append(" ");
    }
    return res.toString().trim();
  }
}
