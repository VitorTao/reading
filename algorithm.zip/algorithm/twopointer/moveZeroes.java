package algorithm.twopointer;

public class moveZeroes {
  public void moveZeroes(int[] nums) {
    int s = 0;
    int f = 0;
    while (s<nums.length){
      if(nums[s] == 0){
        break;
      }
      s++;
    }
    f=s;
    s++;
    while (s<nums.length){
      if(nums[s] != 0){
        swap(nums,s,f);
        f++;
      }
      s++;
    }
  }

  public void swap(int[] nums,int l,int r){
    int tmp = nums[l];
    nums[l] = nums[r];
    nums[r] = tmp;
  }
}
