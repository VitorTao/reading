//给你一个由 n 个整数组成的数组 nums ，和一个目标值 target 。请你找出并返回满足下述全部条件且不重复的四元组 [nums[a], nums[b
//], nums[c], nums[d]] （若两个四元组元素一一对应，则认为两个四元组重复）：
//
//
// 0 <= a, b, c, d < n
// a、b、c 和 d 互不相同
// nums[a] + nums[b] + nums[c] + nums[d] == target
//
//
// 你可以按 任意顺序 返回答案 。
//
//
//
// 示例 1：
//
//
//输入：nums = [1,0,-1,0,-2,2], target = 0
//输出：[[-2,-1,1,2],[-2,0,0,2],[-1,0,0,1]]
//
//
// 示例 2：
//
//
//输入：nums = [2,2,2,2,2], target = 8
//输出：[[2,2,2,2]]
//
//
//
//
// 提示：
//
//
// 1 <= nums.length <= 200
// -109 <= nums[i] <= 109
// -109 <= target <= 109
//
// Related Topics 数组 双指针 排序
// 👍 1407 👎 0
package algorithm.twopointer;

import algorithm.sort.quicksort;

import java.util.ArrayList;
import java.util.List;
//因为官方增加了一个新的用例
//  {1000000000，1000000000，1000000000，1000000000} 0
//  导致了代码出现溢出错误，是因为int的只能到表示[-2147483648,2147483647]，所以在判断
//  num[a]+num[b]+num[c]+num[d]<target
//	时会溢出。因为不想对代码进行大改了所以将表达式调整为
//    nums[a]+nums[b]-target<-(nums[c]+nums[d])
//  这样子就不会溢出了。当然也可以使用long long int来表示数值
public class fourSum {
  public List<List<Integer>> fourSum(int[] nums, int target) {
    List<List<Integer>> res = new ArrayList<>();
    int n = nums.length;
    quicksort(nums,0,n-1);
    for (int i = 0; i < n-3; i++) {
      if(i>0 && nums[i] == nums[i-1]) continue;
      for (int j = i+1; j < n-2; j++) {
        if(j>i+1 && nums[j] == nums[j-1]) continue;
        int l = j+1;
        int r = n-1;
        while (l<r){
          if(nums[i]+nums[j]+nums[l]+nums[r]==target){
            List<Integer> in = new ArrayList<>();
            in.add(nums[i]);
            in.add(nums[j]);
            in.add(nums[l]);
            in.add(nums[r]);
            res.add(in);
            while (l<r && nums[l]==nums[l+1]){
              l++;
            }
            while (l<r && nums[r]==nums[r-1]){
              r--;
            }
            l++;
            r--;
          }else if(nums[i]+nums[j]+nums[l]+nums[r]<target){
            l++;
          }else {
            r--;
          }
        }
      }
    }
    return res;
  }

  public void quicksort(int[] nums,int left,int k){
    if(left >= k) return;
    int base = nums[left];
    int l = left;
    int r = k;
    while (l<r){
      while (l<r && nums[r]>=base){
        r--;
      }
      nums[l] = nums[r];
      while (l<r && nums[l]<base){
        l++;
      }
      nums[r] = nums[l];
    }
    nums[l] = base;
    quicksort(nums,left,l-1);
    quicksort(nums,l+1,k);
  }
  public static void main(String[] args) {
    int[] a = new int[]{2,1,0,-1};
    fourSum q = new fourSum();
//    q.quicksort(a,0,a.length-1);
    q.quicksort(a,0,a.length-1);
    for (int i = 0; i < a.length; i++) {
      System.out.println(a[i]);
    }
  }
}
