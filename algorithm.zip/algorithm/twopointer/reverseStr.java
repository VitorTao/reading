package algorithm.twopointer;

public class reverseStr {
  public String reverseStr(String s, int k) {
    char[] c = s.toCharArray();
    for (int j = 0; j < s.length(); j += 2 * k) {
      int start = j;
      int e = Math.min(s.length() - start - 1, k-1)+start;
      while (start < e) {
        c[start] = s.charAt(e);
        c[e] = s.charAt(start);
        start++;
        e--;
      }
    }
    return new String(c);
  }
}
