package algorithm.twopointer;

import java.util.Arrays;
import java.util.List;

public class reverseVowels {
  private static List<Character> vowel = Arrays.asList('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U');

  public String reverseVowels(String s) {
    if(s == null || s.trim() == ""){return null;}
    int l = 0;
    int r = s.length() - 1;
    char[] res = new char[s.length()];
    while (l <= r) {
      char cl = s.charAt(l);
      char cr = s.charAt(r);
      if (!vowel.contains(cl)) {
        res[l++] = cl;
      }
      if (!vowel.contains(cr)) {
        res[r--] = cr;
      }
      if (vowel.contains(cl) && vowel.contains(cr)) {
        res[l++] = cr;
        res[r--] = cl;
      }
    }
    return new String(res);
  }
}
