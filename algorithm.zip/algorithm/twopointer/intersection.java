package algorithm.twopointer;

import java.util.Arrays;

public class intersection {
  public int[] intersection(int[] nums1, int[] nums2) {
    Arrays.sort(nums1);
    Arrays.sort(nums2);
    int i = 0, l = 0, r = 0;
    int[] res = new int[nums1.length];
    while (l < nums1.length && r < nums2.length) {
      if (nums1[l] < nums2[r]) {
        l++;
      } else if (nums1[l] > nums2[r]) {
        r++;
      } else {
        if (i==0 || nums1[l] != res[i-1]) {
          res[i++] = nums1[l];
        }
        l++;
        r++;
      }
    }
    return Arrays.copyOfRange(res,0,i);
  }
}
