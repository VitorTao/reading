package algorithm.twopointer;

public class isHappy {
  public boolean isHappy(int n) {
    int slow = n;
    int fast = getnext(n);
    while ( slow != fast){
      slow = getnext(slow);
      fast = getnext(getnext(fast));
    }
    return slow==1;
  }

  public int getnext(int n){
    int res = 0;
    while (n > 0){
      int n2 = n%10;
      n = n/10;
      res += n2*n2;
    }
    return res;
  }
//    public boolean isHappy(int n) {
//        Set<Integer> set = new HashSet<>();
//        while (n != 1 && !set.contains(n)){
//            set.add(n);
//            n = getnext(n);
//        }
//        return n==1;
//    }
//
//    public int getnext(int n){
//        int res = 0;
//        while (n > 0){
//            int n2 = n%10;
//            n = n/10;
//            res += n2*n2;
//        }
//        return res;
//    }
}
