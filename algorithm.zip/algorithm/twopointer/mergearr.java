package algorithm.twopointer;

public class mergearr {
  public void merge(int[] nums1, int m, int[] nums2, int n) {
    int m1 = 0;
    int n1 = 0;
    int[] num = new int[m + n];
    int cur = 0;
    while (m1 < m || n1 < n) {

      if (m1 == m) {
        cur = nums2[n1++];
      } else if (n1 == n) {
        cur = nums1[m1++];
      } else if (nums1[m1] <= nums2[n1]) {
        cur = nums1[m1++];
      } else {
        cur = nums2[n1++];
      }
      num[m1 + n1 - 1] = cur;
    }
    for (int i = 0; i < m + n; i++) {
      nums1[i] = num[i];
    }
  }
}
