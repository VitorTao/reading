package algorithm.twopointer;

import algorithm.ListNode;

public class rotateRight {
    public ListNode rotateRight(ListNode head, int k) {
        if(head == null || k == 0) return head;
        ListNode slow = head;
        ListNode fast = head;
        ListNode cur = head;
        int n = 0;
        while (cur !=null){
            n++;
            cur = cur.next;
        }
        while (k%n>0){
            fast = fast.next;
            k--;
        }
//
        while (fast.next!=null){
            slow = slow.next;
            fast = fast.next;
        }
        fast.next = head;
        ListNode newhead = slow.next;
        slow.next = null;
        return newhead;
    }
}
