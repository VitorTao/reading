//给你一个链表的头节点 head 和一个特定值 x ，请你对链表进行分隔，使得所有 小于 x 的节点都出现在 大于或等于 x 的节点之前。
//
// 你应当 保留 两个分区中每个节点的初始相对位置。
//
//
//
// 示例 1：
//
//
//输入：head = [1,4,3,2,5,2], x = 3
//输出：[1,2,2,4,3,5]
//
//
// 示例 2：
//
//
//输入：head = [2,1], x = 2
//输出：[1,2]
//
//
//
//
// 提示：
//
//
// 链表中节点的数目在范围 [0, 200] 内
// -100 <= Node.val <= 100
// -200 <= x <= 200
//
// Related Topics 链表 双指针
// 👍 462 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.twopointer;

import algorithm.ListNode;

public class partition {
    public ListNode partition(ListNode head, int x) {
//        快慢指针，快指针一直前进 慢指针小于X的时候前进，直到遇到大于X停止，此时快指针依然前进，遇到小于X的移动到慢指针前面
//        为什么初始化快指针要放在第二个值，因为可以避免第一个值被操作，无论第一个值大于还是小于x，都没有操作移动的必要，
//        假如大于x,那就更不用动，等待循环到后面小于x的挪到它前面就行，所以这个值没有移动的必要，直接从第二个值操作
//
        if(head == null) return null;
        ListNode p = new ListNode(-1);
        ListNode preslow = p;
        preslow.next = head;
        ListNode prefast = head;
        ListNode fast = head.next;
        ListNode slow = head;
        while (fast != null){
            if(slow.val < x){
                preslow = slow;
                slow = slow.next;
                prefast = fast;
            }else if(fast.val < x){
                prefast.next = fast.next;
                preslow.next = fast;
                fast.next = slow;
                preslow = fast;
            }else {
                prefast = fast;
            }
            fast = prefast.next;
        }
        return p.next;
    }

    public static void main(String[] args) {
        ListNode head = new ListNode(1);
        head.next = new ListNode(4);
        head.next.next = new ListNode(3);
        head.next.next.next = new ListNode(2);
        head.next.next.next.next = new ListNode(5);
        head.next.next.next.next.next = new ListNode(2);
        partition p = new partition();
        p.partition(head,3);
    }
//    public static void main(String[] args) {
//        ListNode head = new ListNode(1);
//        head.next = new ListNode(1);
//        partition p = new partition();
//        p.partition(head,2);
//    }
}
