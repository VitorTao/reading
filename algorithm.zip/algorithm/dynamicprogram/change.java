//给你一个整数数组 coins 表示不同面额的硬币，另给一个整数 amount 表示总金额。
//
// 请你计算并返回可以凑成总金额的硬币组合数。如果任何硬币组合都无法凑出总金额，返回 0 。
//
// 假设每一种面额的硬币有无限个。
//
// 题目数据保证结果符合 32 位带符号整数。
//
//
//
//
//
//
// 示例 1：
//
//
//输入：amount = 5, coins = [1, 2, 5]
//输出：4
//解释：有四种方式可以凑成总金额：
//5=5
//5=2+2+1
//5=2+1+1+1
//5=1+1+1+1+1
//
//
// 示例 2：
//
//
//输入：amount = 3, coins = [2]
//输出：0
//解释：只用面额 2 的硬币不能凑成总金额 3 。
//
//
// 示例 3：
//
//
//输入：amount = 10, coins = [10]
//输出：1
//
//
//
//
// 提示：
//
//
// 1 <= coins.length <= 300
// 1 <= coins[i] <= 5000
// coins 中的所有值 互不相同
// 0 <= amount <= 5000
//
// Related Topics 数组 动态规划
// 👍 724 👎 0
package algorithm.dynamicprogram;

public class change {
  //  public int change(int amount, int[] coins) {
//    int[] dp = new int[amount + 1];
  // 通过打印 画图 得到dp[0] = 1 才是正确的 理论解释是  放入背包为0的 情况只有一种
//    dp[0] = 1;
//    for (int i = 0; i < coins.length; i++) {
//    可以正序遍历 相当于一个物品可以无限次添加  所以情况分成 当前硬币coins[i]放入背包  和 不放入背包 两种情况相加就是总组合数
//   coins[i]放入背包的情况 dp[j-coins[i]]  不放入背包的情况 dp[j]
//      for (int j = coins[i]; j <= amount; j++) {
//        dp[j] = dp[j] + dp[j - coins[i]];
//      }
//    }
//    return dp[amount];
//  }
  public int change(int amount, int[] coins) {
    if(amount==0) return 1;
    if(coins.length==0) return 0;
    int[][] dp = new int[coins.length][amount+1];
//    初始化第一列 当amount为0时  只有一种组合方法
    for (int i = 0; i < coins.length; i++) {
      dp[i][0] = 1;
    }
//    初始化第一行  当总金额等于或倍数与第一种硬币时  dp 有一种组合方法 其他默认为0
    for (int j = 1; j <= amount; j++){
      if(j%coins[0]==0){
        dp[0][j] = 1;
      }
    }
    for (int i = 1; i < coins.length; i++) {
      for (int j = 1; j <= amount ; j++) {
        if(j >= coins[i]){
//          dp[i-1][j] 代表不选择第i个硬币时有多少种组合达成amount
//          dp[i][j-coins[i]] 代表 选择过第i个硬币后 去掉当前额度j-coins[i]  有多少种组合方法
          dp[i][j] =  dp[i-1][j]+dp[i][j-coins[i]] ;
        }else{
          dp[i][j] =  dp[i-1][j] ;
        }
      }
    }
//        for (int i = 0; i < coins.length; i++) {
//            for (int j = 0; j < amount+1; j++) {
//                System.out.println(dp[i][j]);
//            }
//        }
    return dp[coins.length-1][amount];
  }
//一维数组 代码
  public int change1(int amount, int[] coins) {
//        一维数组 金额为j时有多少种组合 j=0 时有一种
    int[] dp = new int[amount + 1];
    dp[0] = 1;
//        物品从下标0开始
    for (int i = 0; i < coins.length; i++) {
      for (int j = coins[i]; j <= amount; j++) {
        dp[j] = dp[j] + dp[j - coins[i]];
      }
    }
    return dp[amount];
  }
}
