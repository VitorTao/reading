package algorithm.dynamicprogram;

public class canPartition {
  public boolean canPartition(int[] nums) {
    int sum = 0;
    for (int i = 0; i < nums.length; i++) {
      sum += nums[i];
    }
    if (sum % 2 != 0) return false;
    sum = sum / 2;
    int[] dp = new int[sum + 1];
    for (int i = 0; i < nums.length; i++) {
//            倒序 防止一个物品重复放进去  因为只有一维  在当前层遍历的时候  同一个物品被放进过dp
      for (int j = sum; j >= 0; j--) {
//                物品能放进背包 比大小
        if (j - nums[i] >= 0) {
          dp[j] = Math.max(dp[j], dp[j - nums[i]] + nums[i]);
        }
//                放不下的话维持原来的数据
      }
    }
    return dp[sum] == sum ? true : false;
  }
//    二维数组版
//    public boolean canPartition(int[] nums) {
//        int sum = 0;
//        for (int i = 0; i < nums.length; i++) {
//            sum += nums[i];
//        }
//        if(sum%2!=0)return false;
//        sum = sum/2;
//        int[][] dp = new int[nums.length][sum+1];
//        for (int i = 0; i < nums.length; i++) {
//            dp[i][0] = 0;
//        }
//        for (int i = sum; i > 0; i--) {
//            if(i>=nums[0]){
//                dp[0][i] = nums[0];
//            }
//        }
//        for (int i = 1; i < nums.length; i++) {
//            for (int j = 1; j <= sum; j++) {
//                if(j-nums[i]>=0){
//                    dp[i][j] = Math.max(dp[i-1][j],dp[i-1][j-nums[i]]+nums[i]);
//                }else {
//                    dp[i][j] = dp[i-1][j];
//                }
//            }
//        }
//        return dp[nums.length-1][sum] == sum?true:false;
//    }

}
