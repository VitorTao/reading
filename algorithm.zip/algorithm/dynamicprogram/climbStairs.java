package algorithm.dynamicprogram;
//假设你正在爬楼梯。需要 n 阶你才能到达楼顶。
//
// 每次你可以爬 1 或 2 个台阶。你有多少种不同的方法可以爬到楼顶呢？
//
//
//
// 示例 1：
//
//
//输入：n = 2
//输出：2
//解释：有两种方法可以爬到楼顶。
//1. 1 阶 + 1 阶
//2. 2 阶
//
// 示例 2：
//
//
//输入：n = 3
//输出：3
//解释：有三种方法可以爬到楼顶。
//1. 1 阶 + 1 阶 + 1 阶
//2. 1 阶 + 2 阶
//3. 2 阶 + 1 阶
//
//
//
//
// 提示：
//
//
// 1 <= n <= 45
//
// Related Topics 记忆化搜索 数学 动态规划
// 👍 2936 👎 0
public class climbStairs {
  //  public int climbStairs(int n) {
//    if(n<=2) return n;
//    int[] r = new int[n+1];
//    r[1] = 1;
//    r[2] = 2;
//    for (int i = 3; i <= n; i++) {
//      r[i] = r[i-1]+r[i-2];
//    }
//    return r[n];
//  }
//执行耗时:0 ms,击败了100.00% 的Java用户
//			内存消耗:35.2 MB,击败了42.22% 的Java用户
//  public int climbStairs(int n) {
//    if(n<=2) return n;
//    int n1 = 1;
//    int n2 = 2;
//    int res = 3;
//    for (int i = 3; i <= n; i++) {
////            r[i] = r[i-1]+r[i-2];
//      res = n1+n2;
//      n1 = n2;
//      n2 = res;
//    }
//    return res;
//  }
//  public int climbStairs(int n) {
//    if (n <= 2) return n;
//    int[] arr = new int[]{1, 2};
//    int[] dp = new int[n + 1];
//    dp[0] = 1;
//    for (int j = 1; j <= n; j++) {
//      for (int i = 0; i < arr.length; i++) {
//        if (j >= arr[i]) {
//          dp[j] = dp[j] + dp[j - arr[i]];
//        }
//      }
//    }
//
//    return dp[n];
//  }
//  public int climbStairs(int n) {
//    if(n<=2) return n;
//    int[] arr = new int[]{1,2};
//    int[][] dp = new int[arr.length][n+1];
//    for (int i = 0; i < arr.length; i++) {
//      dp[i][0] = 0;
//    }
//    for (int i = arr[0]; i <= n; i++) {
//      dp[0][i] = 1;
//    }
//    for (int i = 1; i < arr.length; i++) {
//      for (int j = 1; j <= n; j++) {
//        if(j >= arr[i]){
//          dp[i][j] = dp[i-1][j]+dp[i][j-arr[i]];
//        }else {
//          dp[i][j] = dp[i-1][j];
//        }
//
//      }
//    }
//
//    return dp[arr.length-1][n];
//  }
  public int climbStairs(int n) {
    if (n <= 2) return n;
    int[] arr = new int[]{1, 2};
    int[][] dp = new int[arr.length][n + 1];
    for (int i = 0; i < arr.length; i++) {
      dp[i][0] = 0;
    }
    for (int i = arr[0]; i <= n; i++) {
      dp[0][i] = 1;
    }
    for (int j = 1; j <= n; j++) {
      for (int i = 1; i < arr.length; i++) {
        if (j >= arr[i]) {
          dp[i][j] = dp[i - 1][j] + dp[i][j - arr[i]];
        } else {
          dp[i][j] = dp[i - 1][j];
        }

      }
    }

    return dp[arr.length - 1][n];
  }

  public static void main(String[] args) {
    climbStairs c = new climbStairs();
    System.out.println(c.climbStairs(3));
  }
}
