package algorithm.dynamicprogram;
//给你一个整数数组 nums 和一个整数 target 。
//
// 向数组中的每个整数前添加 '+' 或 '-' ，然后串联起所有整数，可以构造一个 表达式 ：
//
//
// 例如，nums = [2, 1] ，可以在 2 之前添加 '+' ，在 1 之前添加 '-' ，然后串联起来得到表达式 "+2-1" 。
//
//
// 返回可以通过上述方法构造的、运算结果等于 target 的不同 表达式 的数目。
//
//
//
// 示例 1：
//
//
//输入：nums = [1,1,1,1,1], target = 3
//输出：5
//解释：一共有 5 种方法让最终目标和为 3 。
//-1 + 1 + 1 + 1 + 1 = 3
//+1 - 1 + 1 + 1 + 1 = 3
//+1 + 1 - 1 + 1 + 1 = 3
//+1 + 1 + 1 - 1 + 1 = 3
//+1 + 1 + 1 + 1 - 1 = 3
//
//
// 示例 2：
//
//
//输入：nums = [1], target = 1
//输出：1
//
//
//
//
// 提示：
//
//
// 1 <= nums.length <= 20
// 0 <= nums[i] <= 1000
// 0 <= sum(nums[i]) <= 1000
// -1000 <= target <= 1000
//
// Related Topics 数组 动态规划 回溯
// 👍 1560 👎 0
public class findTargetSumWays {
//   想成一堆背包 减去另一堆背包  得到目标和  转化成背包
  public int findTargetSumWays(int[] nums, int target) {
    int sum = 0;
    for (int i = 0; i < nums.length; i++) {
      sum += nums[i];
    }
    if ((target + sum) % 2 == 1) return 0; // 此时没有方案
    int left = (target+sum)/2;
    if(left < 0)return 0;
    int[] dp = new int[left+1];
    dp[0] = 1;
    for (int i = 0; i < nums.length; i++) {
      for (int j = left; j >= nums[i] ; j--) {
        // 装满容量为j的包  有dp[j]种方案 1： 假如此时装上nums[i]
        //那之前只能找装满 容量j-nums[i]有多少方案 dp[j-nums[i]] + nums[i]当前这个背包就是dp[j]种方法
        // 2：假如此时不装上nums[i] 那就找之前的dp[j]有几种方案 ，此时两种方案相加 得到dp[j-nums[i]]+dp[j]
        dp[j] = dp[j]+dp[j-nums[i]];
      }
    }
    return dp[left];
  }
// 二维数组解法
  public int findTargetSumWays2(int[] nums, int target) {
    int sum = 0;
    int left = 0;
    for (int i = 0; i < nums.length; i++) {
      sum += nums[i];
    }
    if((sum+target)%2!=0)return 0;
    left = (sum+target)/2;
    int[][] dp = new int[nums.length][left+1];
//    和为0  不放任何东西 就是0  也是一种方法 所以为1
    dp[0][0]=1;
    for (int i = 1; i <= left; i++) {
      if(i == nums[0]){
        dp[0][i] = 1;
      }
    }
//    有个特殊情况  假如第一个数是0  那么+0 -0 都能得到0 即放不放 共有两种方式得到0
    if(nums[0]==0){
      dp[0][0]=2;
    }
    for (int i = 1; i < nums.length; i++) {
      for (int j = 0; j <= left ; j++) {
        if(j-nums[i]>=0){
          dp[i][j] = dp[i-1][j]+dp[i-1][j-nums[i]];
        }else {
          dp[i][j] = dp[i-1][j];
        }
      }
    }
    return dp[nums.length-1][left];
  }
}
