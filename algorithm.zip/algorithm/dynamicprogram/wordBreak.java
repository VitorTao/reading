package algorithm.dynamicprogram;
//给你一个字符串 s 和一个字符串列表 wordDict 作为字典。请你判断是否可以利用字典中出现的单词拼接出 s 。
//
// 注意：不要求字典中出现的单词全部都使用，并且字典中的单词可以重复使用。
//
//
//
// 示例 1：
//
//
//输入: s = "leetcode", wordDict = ["leet", "code"]
//输出: true
//解释: 返回 true 因为 "leetcode" 可以由 "leet" 和 "code" 拼接成。
//
//
// 示例 2：
//
//
//输入: s = "applepenapple", wordDict = ["apple", "pen"]
//输出: true
//解释: 返回 true 因为 "applepenapple" 可以由 "apple" "pen" "apple" 拼接成。
//     注意，你可以重复使用字典中的单词。
//
//
// 示例 3：
//
//
//输入: s = "catsandog", wordDict = ["cats", "dog", "sand", "and", "cat"]
//输出: false
//
//
//
//
// 提示：
//
//
// 1 <= s.length <= 300
// 1 <= wordDict.length <= 1000
// 1 <= wordDict[i].length <= 20
// s 和 wordDict[i] 仅有小写英文字母组成
// wordDict 中的所有字符串 互不相同
//
// Related Topics 字典树 记忆化搜索 数组 哈希表 字符串 动态规划
// 👍 2032 👎 0

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class wordBreak {

  public boolean wordBreak(String s, List<String> wordDict) {
    int n = s.length();
    boolean[] dp = new boolean[n + 1];
    dp[0] = true;
//  wordDict 是物品   s 的长度是背包 等于先遍历背包 后遍历物品  如果先遍历物品 只能获取leetleetcode  获取不到leetcodeleet
    for (int i = 1; i <= n; i++) {
//    正常逻辑遍历物品 应该是遍历 字典的字符串 但是此题特殊  需要重复截取字符串 需要有个标识 来确定截取的起始位置
//      所以用下面这种遍历方式  借助 dp[j]一步步  得到dp[i] 的结果
      for (int j = 0; j < i; j++) {
        if (dp[j] && wordDict.contains(s.substring(j,i))) {
          dp[i] = true;
          break;
        }
      }
    }
    return dp[n];
  }
//  public boolean wordBreak(String s, List<String> wordDict) {
//    boolean[] dp = new boolean[s.length() + 1];
//    dp[0] = true;
//    for (int i = 1; i <= s.length(); i++) {
//      for (String str : wordDict) {
//        int num = str.length();
//  这个思路很妙  解决了 记录截取起始位置的问题  假如是leetcodeleet
//        if (i >= num) {
//          dp[i] = dp[i] || (dp[i-num] && wordDict.contains(s.substring(i-num,i)));
//        }
//      }
//    }
//    return dp[s.length()];
//
//  }

//  public boolean wordBreak(String s, List<String> wordDict) {
//
//    boolean[] dp = new boolean[s.length()+1];
//    dp[0] = true;
//    for (int i = 1; i <= s.length(); i++) {
//      for (int j = 0; j <i ; j++) {
//        if(dp[j] && wordDict.contains(s.substring(j,i))){
//          dp[i] = true;
//          break;
//        }
//      }
//    }
//    return dp[s.length()];
//  }

  public static void main(String[] args) {
    System.out.println("leetcode".substring(0, 4));
  }
}
