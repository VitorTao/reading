package algorithm.dynamicprogram;

public class maxSubArray {

  //    sum[i] = max{sum[i-1]+a[i],a[i]}
//  执行耗时:1 ms,击败了94.79% 的Java用户
//  内存消耗:38.5 MB,击败了25.83% 的Java用户
  public int maxSubArray(int[] nums) {
    if (nums.length == 1) return nums[0];
    int pre = nums[0];
    int max = nums[0];
    for (int i = 1; i < nums.length; i++) {
      pre = Math.max(pre + nums[i], nums[i]);
      if (pre > max) {
        max = pre;
      }
    }
    return max;
  }
//执行耗时:1 ms,击败了94.80% 的Java用户
//			内存消耗:38.4 MB,击败了57.83% 的Java用户
//  public int maxSubArray(int[] nums) {
//        int[] dp = new int[nums.length];
//        dp[0]=nums[0];
//        int res = nums[0];
//        for (int i = 1; i < nums.length; i++) {
//            dp[i] = Math.max(nums[i],dp[i-1]+nums[i]);
//            res = Math.max(res,dp[i]);
//        }
//        return res;
//    }
//  执行耗时:58 ms,击败了6.54% 的Java用户
//			内存消耗:39.5 MB,击败了5.30% 的Java用户
//  public int maxSubArray(int[] nums) {
//    if (nums.length == 1) return nums[0];
//    int[] dp = new int[nums.length];
//    dp[0] = nums[0];
//    int max = nums[0];
//    for (int i = 1; i < nums.length; i++) {
//      dp[i] = Math.max(dp[i - 1] + nums[i], nums[i]);
//      if(dp[i] > max){
//          max = dp[i];
//      }
//      System.out.println(dp[i]);
//    }
//    return max;
//  }
}
