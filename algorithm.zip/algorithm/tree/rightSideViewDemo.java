package algorithm.tree;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class rightSideViewDemo {
  public List<Integer> rightSideView(TreeNode root) {
    Queue<TreeNode> q = new LinkedBlockingQueue();
    List<Integer> res = new ArrayList<>();
    if(root==null)return res;
    q.add(root);
    while (!q.isEmpty()){
      int size=q.size();
      for (int i = 0; i < size; i++) {
        TreeNode poll = q.poll();
        if(poll.left != null){
          q.add(poll.left);
        }
        if(poll.right != null){
          q.add(poll.right);
        }
        if(i == size-1){
          res.add(poll.val);
        }
      }
    }
  return res;
  }
}
