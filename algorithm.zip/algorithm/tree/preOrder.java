package algorithm.tree;

import java.util.ArrayList;
import java.util.List;

public class preOrder {
    List<Integer> l ;
    public List<Integer> preOrder(TreeNode root) {
        l = new ArrayList<>();
        dfs(l,root);
        return l;
    }

    private void dfs(List<Integer> l,TreeNode root) {
        if(root==null)return;
        l.add(root.val);
        System.out.println(root.val);
        dfs(l,root.left);
        dfs(l,root.right);
    }

    public static void main(String[] args) {
        TreeNode root = new TreeNode(2,new TreeNode(1),new TreeNode(3));
        preOrder p = new preOrder();
        p.preOrder(root);
    }
}
