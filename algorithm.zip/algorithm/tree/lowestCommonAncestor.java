package algorithm.tree;

import algorithm.tree.inorderTraversal;

import java.util.*;

public class lowestCommonAncestor {
//  获取 p,q 的路径 ，然后遍历直到最近的公共节点
  public inorderTraversal.TreeNode lowestCommonAncestor(inorderTraversal.TreeNode root, inorderTraversal.TreeNode p, inorderTraversal.TreeNode q) {
    inorderTraversal.TreeNode h = root;
    Queue<inorderTraversal.TreeNode> s1 = dfs(h, p);
    Queue<inorderTraversal.TreeNode> s2 = dfs(h, q);
    inorderTraversal.TreeNode res = null ;
    for (int i = 0; i < s1.size() && i< s2.size() ; i++) {
      inorderTraversal.TreeNode p1 = s1.poll();
      inorderTraversal.TreeNode p2 = s2.poll();
      System.out.println(p1.val);
      System.out.println(p2.val);
      if(p1==p2){
        res = p1;
      }
    }
    return res;
  }

  public Queue<inorderTraversal.TreeNode> dfs(inorderTraversal.TreeNode h1, inorderTraversal.TreeNode t) {
    Queue<inorderTraversal.TreeNode> s = new LinkedList<>();
    inorderTraversal.TreeNode h = h1;
    while (h != null) {
      s.offer(h);
      if (h.val == t.val) {
        return s;
      } else if (h.val > t.val) {
        h = h.left;
      } else if (h.val < t.val) {
        h = h.right;
      }
    }
    return s;
  }
}
