package algorithm.tree;
//给你一个大小为 n x n 二进制矩阵 grid 。最多 只能将一格 0 变成 1 。
//
// 返回执行此操作后，grid 中最大的岛屿面积是多少？
//
// 岛屿 由一组上、下、左、右四个方向相连的 1 形成。
//
//
//
// 示例 1:
//
//
//输入: grid = [[1, 0], [0, 1]]
//输出: 3
//解释: 将一格0变成1，最终连通两个小岛得到面积为 3 的岛屿。
//
//
// 示例 2:
//
//
//输入: grid = [[1, 1], [1, 0]]
//输出: 4
//解释: 将一格0变成1，岛屿的面积扩大为 4。
//
// 示例 3:
//
//
//输入: grid = [[1, 1], [1, 1]]
//输出: 4
//解释: 没有0可以让我们变成1，面积依然为 4。
//
//
//
// 提示：
//
//
// n == grid.length
// n == grid[i].length
// 1 <= n <= 500
// grid[i][j] 为 0 或 1
//
// Related Topics 深度优先搜索 广度优先搜索 并查集 数组 矩阵
// 👍 332 👎 0
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class largestIsland {
  int index = 2;
  Map<Integer,Integer> map = new HashMap<>();
  public int largestIsland(int[][] grid) {
    int res = 0;
    for (int i = 0; i < grid.length; i++) {
      for (int j = 0; j < grid[0].length; j++) {
        if(grid[i][j]==1){
          map.put(index,area(grid,i,j));
          index++;
        }
      }
    }
    for (int i = 0; i < grid.length; i++) {
      for (int j = 0; j < grid[0].length; j++) {
        if(grid[i][j]==0){
          res = Math.max(res,through(grid,i,j));
        }
      }
    }
    for(Map.Entry<Integer,Integer> e:map.entrySet()){
      System.out.println(e.getKey()+"="+e.getValue());
      res = Math.max(res,e.getValue());
    }
    return res;
  }
  public int through(int[][] grid,int x,int y){
    int m = grid.length;
    int n = grid[0].length;
    int[][] direct = {{0,1},{0,-1},{1,0},{-1,0}};
    Set<Integer> set = new HashSet<>();
    int res = 0;
    for (int i = 0; i < direct.length; i++) {
      int newi = x+direct[i][0];
      int newj = y+direct[i][1];
      if(newi >=0 && newj >= 0 && newi < m && newj < n && !set.contains(grid[newi][newj])){
        set.add(grid[newi][newj]);
        System.out.println(map.getOrDefault(grid[newi][newj],0));
        res += map.getOrDefault(grid[newi][newj],0);
      }
    }
    return res+1;
  }

  public int area(int[][] grid,int x,int y){
    if(x<0 || y<0 || x>= grid.length || y>= grid[0].length || grid[x][y]!=1 || grid[x][y]==0) return 0;
    grid[x][y] = index;
    return 1+area(grid,x-1,y)+area(grid,x+1,y)+area(grid,x,y-1)+area(grid,x,y+1);
  }

  public static void main(String[] args) {
    largestIsland l = new largestIsland();
    int[][] grid = {{1,0},{0,1}};
    l.largestIsland(grid);
  }
}
