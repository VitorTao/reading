//给你一个二叉树的根节点 root ，树中每个节点都存放有一个 0 到 9 之间的数字。
//
//
// 每条从根节点到叶节点的路径都代表一个数字：
//
//
// 例如，从根节点到叶节点的路径 1 -> 2 -> 3 表示数字 123 。
//
//
// 计算从根节点到叶节点生成的 所有数字之和 。
//
// 叶节点 是指没有子节点的节点。
//
//
//
// 示例 1：
//
//
//输入：root = [1,2,3]
//输出：25
//解释：
//从根到叶子节点路径 1->2 代表数字 12
//从根到叶子节点路径 1->3 代表数字 13
//因此，数字总和 = 12 + 13 = 25
//
// 示例 2：
//
//
//输入：root = [4,9,0,5,1]
//输出：1026
//解释：
//从根到叶子节点路径 4->9->5 代表数字 495
//从根到叶子节点路径 4->9->1 代表数字 491
//从根到叶子节点路径 4->0 代表数字 40
//因此，数字总和 = 495 + 491 + 40 = 1026
//
//
//
//
// 提示：
//
//
// 树中节点的数目在范围 [1, 1000] 内
// 0 <= Node.val <= 9
// 树的深度不超过 10
//
//
//
// Related Topics 树 深度优先搜索 二叉树
// 👍 589 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.tree;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class sumNumbers {
  List<List<String>> list = new ArrayList<>();
  public int sumNumbers(TreeNode root) {
    dfs(root,new ArrayList<>());
    int sum = 0;
    for (int i = 0; i < list.size(); i++) {
      String s = list.get(i).stream().collect(Collectors.joining(""));
      System.out.println(Integer.valueOf(s));
      sum += Integer.valueOf(s);
    }
    return sum;
  }

  public void dfs(TreeNode root,List<String> inner){
    if(root==null)return;
    inner.add(String.valueOf(root.val));
    if(root.left == null && root.right == null) {
      list.add(new ArrayList<>(inner));
//      剪枝
      inner.remove(inner.size()-1);
      return;
    };
    dfs(root.left,inner);
    dfs(root.right,inner);
//    结束后本层也得剪枝
    inner.remove(inner.size()-1);
  }
  public int sumNumbers1(TreeNode root) {
    return  dfs1(root,0);
  }

  public int dfs1(TreeNode root,int pre){
    if(root==null)return 0;
    pre = pre*10 + root.val;
    if(root.left == null && root.right == null) {
      return pre;
    };
    return  dfs1(root.left,pre)+dfs1(root.right,pre);
  }
  public static void main(String[] args) {
    sumNumbers s = new sumNumbers();
//    TreeNode root = new TreeNode(1);
//    root.left = new TreeNode(2);
//    root.right = new TreeNode(3);
//    TreeNode root = new TreeNode(4);
//    TreeNode son = new TreeNode(9);
//    son.left = new TreeNode(5);
//    son.right = new TreeNode(1);
//    root.left = son;
//    root.right = new TreeNode(0);
    TreeNode root = new TreeNode(0);
    root.left = new TreeNode(1);
    s.sumNumbers(root);
  }
}
