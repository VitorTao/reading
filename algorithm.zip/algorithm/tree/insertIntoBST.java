//给定二叉搜索树（BST）的根节点 root 和要插入树中的值 value ，将值插入二叉搜索树。 返回插入后二叉搜索树的根节点。 输入数据 保证 ，新值和原
//始二叉搜索树中的任意节点值都不同。
//
// 注意，可能存在多种有效的插入方式，只要树在插入后仍保持为二叉搜索树即可。 你可以返回 任意有效的结果 。
//
//
//
// 示例 1：
//
//
//输入：root = [4,2,7,1,3], val = 5
//输出：[4,2,7,1,3,5]
//解释：另一个满足题目要求可以通过的树是：
//
//
//
// 示例 2：
//
//
//输入：root = [40,20,60,10,30,50,70], val = 25
//输出：[40,20,60,10,30,50,70,null,null,25]
//
//
// 示例 3：
//
//
//输入：root = [4,2,7,1,3,null,null,null,null,null,null], val = 5
//输出：[4,2,7,1,3,5]
//
//
//
//
// 提示：
//
//
// 树中的节点数将在 [0, 104]的范围内。
// -108 <= Node.val <= 108
// 所有值 Node.val 是 独一无二 的。
// -108 <= val <= 108
// 保证 val 在原始BST中不存在。
//
// Related Topics 树 二叉搜索树 二叉树
// 👍 282 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.tree;

public class insertIntoBST {
//    当将 textitval  插入到以 textitroot  为根的子树上时，根据  textitval  与 textitrootval  的大小关系，就可以确定要将 textitval  插入到哪个子树中。
//    如果该子树不为空，则问题转化成了将 textitval  插入到对应子树上。
//    否则，在此处新建一个以 textitval  为值的节点，并链接到其父节点 textitroot  上。
    public TreeNode insertIntoBST(TreeNode root, int val) {
        if(root == null) return new TreeNode(val);
        if(root.val > val){
            if(root.left == null){
                root.left = new TreeNode(val);
            }else {
                root.left = insertIntoBST(root.left,val);
            }
        }
        if(root.val < val){
            if(root.right == null){
                root.right = new TreeNode(val);
            }else {
                root.right = insertIntoBST(root.right,val);
            }
        }
        return root;
    }
}
