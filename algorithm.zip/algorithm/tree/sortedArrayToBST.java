package algorithm.tree;


public class sortedArrayToBST {
//  二叉搜索树的中序遍历是升序序列，题目给定的数组是按照升序排序的有序数组，因此可以确保数组是二叉搜索树的中序遍历序列
  public inorderTraversal.TreeNode sortedArrayToBST(int[] nums) {
    return dfs(nums,0,nums.length-1);
  }

  public inorderTraversal.TreeNode dfs(int[] nums,int l,int r){
    if(l > r){
      return null;
    }
    int mid = l+(r-l)/2;
    inorderTraversal.TreeNode root = new inorderTraversal.TreeNode(nums[mid]);
    root.left =  dfs(nums,l,mid-1);
    root.right =  dfs(nums,mid+1,r);
    return root;
  }

  public TreeNode demo(int[] nums,int l,int r){
    if(l>=r)return null;
    int mid = l+(r-l)/2;
    TreeNode m = new TreeNode(nums[mid]);
    m.left = this.demo(nums,l,mid-1);
    m.right = this.demo(nums,mid+1,r);
    return m;
  }
}
