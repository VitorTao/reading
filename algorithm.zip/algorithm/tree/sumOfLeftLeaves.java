package algorithm.tree;

import algorithm.tree.inorderTraversal;

public class sumOfLeftLeaves {
  public int sumOfLeftLeaves(inorderTraversal.TreeNode root) {
    return dfs(root);
  }
  public int dfs(inorderTraversal.TreeNode n){
    if(n == null) return 0;
    int sum = 0;
    if(n.left != null ){
      sum += (n.left.left==null && n.left.right==null) ? n.left.val:dfs(n.left);
    }
    if(n.right != null ){
      sum += dfs(n.right);
    }
    return sum;
  }
//  public int sumOfLeftLeaves(inorderTraversal.TreeNode root) {
//    List<List<inorderTraversal.TreeNode>> l = new ArrayList<>();
//    Queue<inorderTraversal.TreeNode> q = new LinkedBlockingQueue<>();
//    if (root == null) return 0;
//    q.offer(root);
//    int sum = 0;
//    while (!q.isEmpty()) {
//      int size = q.size();
//      for (int i = 0; i < size; i++) {
//        inorderTraversal.TreeNode n = q.poll();
//        if(n.left != null && n.left.left==null && n.left.right==null){
//          sum += n.left.val;
//        }
//        if (n.left != null) {
//          q.offer(n.left);
//        }
//        if (n.right != null) {
//          q.offer(n.right);
//        }
//      }
//    }
//    return sum;
//  }
}
