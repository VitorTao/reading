//给你一个二叉树的根节点 root ，判断其是否是一个有效的二叉搜索树。
//
// 有效 二叉搜索树定义如下：
//
//
// 节点的左子树只包含 小于 当前节点的数。
// 节点的右子树只包含 大于 当前节点的数。
// 所有左子树和右子树自身必须也是二叉搜索树。
//
//
//
//
// 示例 1：
//
//
//输入：root = [2,1,3]
//输出：true
//
//
// 示例 2：
//
//
//输入：root = [5,1,4,null,null,3,6]
//输出：false
//解释：根节点的值是 5 ，但是右子节点的值是 4 。
//
//
//
//
// 提示：
//
//
// 树中节点数目范围在[1, 104] 内
// -231 <= Node.val <= 231 - 1
//
// Related Topics 树 深度优先搜索 二叉搜索树 二叉树
// 👍 1489 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.tree;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode() {}
 *     TreeNode(int val) { this.val = val; }
 *     TreeNode(int val, TreeNode left, TreeNode right) {
 *         this.val = val;
 *         this.left = left;
 *         this.right = right;
 *     }
 * }
 */
public class isValidBST {
//    long 比 int 范围大  利用中序遍历  假如没有升序 说明不是搜索二叉树
    long pre = Long.MIN_VALUE;
    boolean res = true;
    public boolean isValidBST(TreeNode root) {
        dfs(root);
        return res;
    }

    private void dfs(TreeNode root) {
        if(root==null) return ;
        dfs(root.left);
        if(pre>=root.val){
            res = false;
            return;
        }else {
            pre = root.val;
        }
        dfs(root.right);
    }


    public boolean isValidBST1(TreeNode root) {
        Queue<TreeNode> q = new LinkedBlockingQueue<>();
        q.offer(root);
        while (!q.isEmpty()){
            TreeNode poll = q.poll();
            if(poll.left != null){
                if(poll.left.val < poll.val){
                    q.offer(poll.left);
                }else {
                    return false;
                }
            }
            if(poll.right != null){
                if(poll.right.val > poll.val){
                    q.offer(poll.right);
                }else {
                    return false;
                }
            }
        }
        return true;
    }
    public static void main(String[] args) {
//        TreeNode root = new TreeNode(2,new TreeNode(1),new TreeNode(3));
        TreeNode root = new TreeNode(5,new TreeNode(4),new TreeNode(6,new TreeNode(3),new TreeNode(7)));
        isValidBST p = new isValidBST();
        System.out.println(p.isValidBST(root));
    }
}
