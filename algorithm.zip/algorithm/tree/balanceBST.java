//给你一棵二叉搜索树，请你返回一棵 平衡后 的二叉搜索树，新生成的树应该与原来的树有着相同的节点值。如果有多种构造方法，请你返回任意一种。
//
// 如果一棵二叉搜索树中，每个节点的两棵子树高度差不超过 1 ，我们就称这棵二叉搜索树是 平衡的 。
//
//
//
// 示例 1：
//
//
//
//
//输入：root = [1,null,2,null,3,null,4,null,null]
//输出：[2,1,3,null,null,null,4]
//解释：这不是唯一的正确答案，[3,1,4,null,2,null,null] 也是一个可行的构造方案。
//
//
// 示例 2：
//
//
//
//
//输入: root = [2,1,3]
//输出: [2,1,3]
//
//
//
//
// 提示：
//
//
// 树节点的数目在 [1, 104] 范围内。
// 1 <= Node.val <= 105
//
// Related Topics 贪心 树 深度优先搜索 二叉搜索树 分治 二叉树
// 👍 104 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.tree;

import java.util.ArrayList;
import java.util.List;

//长度为 k 的区间与长度为 k + 1 的区间（其中 kgeq1  ）按照以上方法构造出的二叉树的最大高度差不超过 1。证明过程如下：
//左右子树的大小越「平均」，这棵树会不会越平衡？于是一种贪心策略的雏形就形成了：我们可以通过中序遍历将原来的二叉搜索树转化为一个有序序列，然后对这个有序序列递归建树，对于区间 [L, R]：
public class balanceBST {
    List<Integer> list = new ArrayList<>();
    public TreeNode balanceBST(TreeNode root) {
        dfs(root);
        return build(0,list.size()-1);
    }

    private TreeNode build(int s, int e) {
        if(s>e)return null;
        int mid = (s+e)/2;
        TreeNode root = new TreeNode(list.get(mid));
        root.left = build(s,mid-1);
        root.right = build(mid+1,e);
        return root;
    }

    public void dfs(TreeNode root){
        if(root == null) return;
        dfs(root.left);
        list.add(root.val);
        dfs(root.right);
    }
}
