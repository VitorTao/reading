package algorithm.tree;

import algorithm.tree.inorderTraversal;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class levelOrderBottom {
  public List<List<Integer>> levelOrderBottom(inorderTraversal.TreeNode root) {
    Queue<inorderTraversal.TreeNode> q = new LinkedList<>();
    List<List<Integer>> res = new ArrayList<>();
    if(root == null) return res;
    q.offer(root);
    while (!q.isEmpty()){
      int size = q.size();
      List<Integer> in = new ArrayList<>();
      for (int i = 0; i < size; i++) {
        inorderTraversal.TreeNode n = q.poll();
        in.add(n.val);
        if(n.left != null){
          q.offer(n.left);
        }
        if(n.right != null){
          q.offer(n.right);
        }
      }
      res.add(0,in);
    }
    return res;
  }
}
