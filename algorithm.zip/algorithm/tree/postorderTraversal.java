package algorithm.tree;

import algorithm.tree.inorderTraversal;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class postorderTraversal {
  public List<Integer> postorderTraversal(inorderTraversal.TreeNode root) {
//        类似先序遍历的反转 ，先序遍历先中右左  然后倒过来就是左右中
    List<Integer> res = new ArrayList<>();
    Stack<inorderTraversal.TreeNode> s = new Stack<inorderTraversal.TreeNode>();
    Stack<inorderTraversal.TreeNode> s1 = new Stack<inorderTraversal.TreeNode>();
    if(root==null)return res;
    s.push(root);
    while (!s.empty()){
      inorderTraversal.TreeNode t = s.pop();
      s1.push(t);
      if(t.left != null){
        s.push(t.left);
      }
      if(t.right != null){
        s.push(t.right);
      }
    }
    while (!s1.empty()){
      res.add(s1.pop().val);
    }
    return res;
  }
  //    public List<Integer> postorderTraversal(TreeNode root) {
//        List<Integer> res = new ArrayList<>();
//        dfs(root,res);
//        return res;
//    }
  public void dfs(inorderTraversal.TreeNode root, List<Integer> res){
    if(root==null){
      return;
    }
    dfs(root.left,res);
    dfs(root.right,res);
    res.add(root.val);
  }
}
