package algorithm.tree;

public class findBottomLeftValue {
  int max = 0;
  int value = 0;

  public int findBottomLeftValue(TreeNode root) {
    dfs(root,1);
    return value;
  }

  void dfs(TreeNode root,int level) {
    if (root.left == null && root.right == null) {
      if (level > max) {
        max = level;
        value = root.val ;
      }
      return;
    }
    level++;
    if(root.left != null){
      dfs(root.left,level);
    }
    if(root.right != null){
      dfs(root.right,level);
    }

  }
}
class TreeNode {
  int val;
  TreeNode left;
  TreeNode right;
  TreeNode() {}
  TreeNode(int val) { this.val = val; }
  TreeNode(int val, TreeNode left, TreeNode right) {
  this.val = val;
  this.left = left;
  this.right = right;
  }
  }
