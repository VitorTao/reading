//给你二叉搜索树的根节点 root ，该树中的 恰好 两个节点的值被错误地交换。请在不改变其结构的情况下，恢复这棵树 。
//
//
//
// 示例 1：
//
//
//输入：root = [1,3,null,null,2]
//输出：[3,1,null,null,2]
//解释：3 不能是 1 的左孩子，因为 3 > 1 。交换 1 和 3 使二叉搜索树有效。
//
//
// 示例 2：
//
//
//输入：root = [3,1,4,null,null,2]
//输出：[2,1,4,null,null,3]
//解释：2 不能在 3 的右子树中，因为 2 < 3 。交换 2 和 3 使二叉搜索树有效。
//
//
//
// 提示：
//
//
// 树上节点的数目在范围 [2, 1000] 内
// -231 <= Node.val <= 231 - 1
//
//
//
//
// 进阶：使用 O(n) 空间复杂度的解法很容易实现。你能想出一个只使用 O(1) 空间的解决方案吗？
// Related Topics 树 深度优先搜索 二叉搜索树 二叉树
// 👍 685 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.tree;

import java.util.ArrayList;
import java.util.List;

public class recoverTree {
//    巧妙思路  把值交换一下就行  不需要考虑左右孩子的交换
//    中序遍历遍历元素是递增的
//    我们来看下如果在一个递增的序列中交换两个值会造成什么影响。假设有一个递增序列 *a=[1,2,3,4,5,6,7]*。
//    如果我们交换两个不相邻的数字，例如 *2* 和 *6*，原序列变成了 *a=[1,6,3,4,5,2,7]*，那么显然序列中有两个位置不满足 *a_i<a_{i+1}*，在这个序列中体现为 *6>3*，*5>2*，因此只要我们找到这两个位置，即可找到被错误交换的两个节点。如果我们交换两个相邻的数字，例如 *2* 和 *3*，此时交换后的序列只有一个位置不满足 *a_i<a_{i+1}*。因此整个值序列中不满足条件的位置或者有两个，或者有一个。
    List<TreeNode> arr = new ArrayList<>();
    TreeNode firstNode = null;
    TreeNode secondNode = null;
    TreeNode pre = new TreeNode(Integer.MIN_VALUE);
    public void recoverTree(TreeNode root) {
        dfs(root);
        for (int j = 0; j < arr.size()-1; j++) {
            if(firstNode == null && arr.get(j).val >  arr.get(j+1).val){
                firstNode = arr.get(j);
            }
            if(firstNode != null && arr.get(j).val >  arr.get(j+1).val){
                secondNode = arr.get(j+1);
            }
        }
        int tmp = firstNode.val;
        firstNode.val = secondNode.val;
        secondNode.val = tmp;
    }

    public void dfs(TreeNode root){
        if(root==null) return;
        dfs(root.left);
        arr.add(root);
        dfs(root.right);
    }
    public void recoverTree1(TreeNode root) {
        dfs(root);
        int tmp = firstNode.val;
        firstNode.val = secondNode.val;
        secondNode.val = tmp;
    }
    public void dfs1(TreeNode root) {
        if (root == null) return;
        dfs(root.left);
        if (pre.val >= root.val) {
            if (firstNode == null) {
                firstNode = pre;
            }
            if(firstNode != null){
                secondNode = root;
            }
        }
        pre = root;
        dfs(root.right);
    }
    public static void main(String[] args) {
        System.out.println(5/2);
    }
}
