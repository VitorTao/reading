package algorithm.tree;

import algorithm.tree.inorderTraversal;

import java.util.ArrayList;
import java.util.List;

public class lowestCommonAncestorBT {
  List<List<TreeNode>> list = new ArrayList<>();
  public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
    dfs(root,p,new ArrayList<TreeNode>());
    dfs(root,q,new ArrayList<TreeNode>());
    List<TreeNode> p1 = list.get(0);
    List<TreeNode> p2 = list.get(1);
    TreeNode res = null;
    for (int i = 0; i < p1.size() && i < p2.size(); i++) {
      TreeNode t1 = p1.get(i);
      TreeNode t2 = p2.get(i);
      if(t1.val != t2.val){
        break;
      }
      res = t1;
    }
    return res;
  }

  public void dfs(TreeNode root, TreeNode p,ArrayList<TreeNode> l){
    if(root==null)return;
    l.add(root);
    if(root.val == p.val){
      list.add(new ArrayList<>(l));
      return;
    }
    dfs(root.left,p,l);
    dfs(root.right,p,l);
    l.remove(l.size()-1);
  }
}
