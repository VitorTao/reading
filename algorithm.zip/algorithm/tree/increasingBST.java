package algorithm.tree;

import java.util.ArrayList;
import java.util.List;

public class increasingBST {
//    在中序遍历的过程中 修改指针  用一个pre 节点记录前一个节点  这样遍历下一个节点时  前一个节点的右子节点 = 当前节点
    TreeNode pre = null;
    List<Integer> l = new ArrayList<>();
    public TreeNode increasingBST(TreeNode root) {
        TreeNode dummy = new TreeNode(-1);
        pre = dummy;
        dfs(root);
        return dummy.right;
    }

    private void dfs(TreeNode root) {
        if(root==null)return;
        dfs(root.left);
        root.left = null;
        pre.right = root;
        pre = root;
        dfs(root.right);
    }
//    TreeNode pre = null;
//    List<Integer> l = new ArrayList<>();
//    public TreeNode increasingBST(TreeNode root) {
//        dfs(root);
//        TreeNode dummy = new TreeNode(-1);
//        TreeNode head = dummy;
//        for (int i = 0; i < l.size(); i++) {
//            TreeNode node = new TreeNode(l.get(i));
//            dummy.right = node;
//            dummy = dummy.right;
//        }
//        return head.right;
//    }
//
//    private void dfs(TreeNode root) {
//        if(root==null)return;
//        dfs(root.left);
//        l.add(root.val);
//        dfs(root.right);
//    }
}
