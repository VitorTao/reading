package algorithm.tree;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class BSTIterator {
    Queue<TreeNode> q = new LinkedBlockingQueue<>();
    public BSTIterator(TreeNode root) {
        dfs(root);
    }
    public void dfs(TreeNode root){
        if(root==null)return;
        dfs(root.left);
        q.offer(root);
        dfs(root.right);
    }
    public int next() {
        return q.poll().val;
    }

    public boolean hasNext() {
        return q.peek()!=null;
    }
}
