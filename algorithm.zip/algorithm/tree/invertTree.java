package algorithm.tree;

import algorithm.tree.inorderTraversal;

import java.util.LinkedList;
import java.util.Queue;

public class invertTree {
//  广度优先
  public inorderTraversal.TreeNode invertTree(inorderTraversal.TreeNode root) {
    if(root == null) return root;
    Queue<inorderTraversal.TreeNode> q = new LinkedList<>();
    q.offer(root);
    while (!q.isEmpty()){
      inorderTraversal.TreeNode n = q.poll();
      inorderTraversal.TreeNode l = n.left;
      inorderTraversal.TreeNode r = n.right;
      if(l != null){
        q.offer(l);
      }
      if(r != null){
        q.offer(r);
      }
      n.left = r;
      n.right = l;
    }
    return root;
  }
//  深度优先
//  public inorderTraversal.TreeNode invertTree(inorderTraversal.TreeNode root) {
//    if(root == null) return root;
//    inorderTraversal.TreeNode r = root.right;
//    inorderTraversal.TreeNode l = root.left;
//    root.left = invertTree(r);
//    root.right = invertTree(l);
//    return root;
//  }

}
