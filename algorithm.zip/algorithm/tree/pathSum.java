package algorithm.tree;

import algorithm.tree.inorderTraversal;

import java.util.ArrayList;
import java.util.List;

public class pathSum {


  public List<List<Integer>> pathSum(inorderTraversal.TreeNode root, int targetSum) {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> in = new ArrayList<>();
    dfs(root,targetSum,res,in);
    return res;
  }

  public void dfs(inorderTraversal.TreeNode root, int targetSum,List<List<Integer>> res,List<Integer> in){
    if(root == null){
      return ;
    }
    targetSum -= root.val;
    in.add(root.val);
    if(targetSum == 0 && root.left == null && root.right == null){
      res.add(new ArrayList<>(in));
//            一般回溯法需要剪枝 把上一步的数据remove  防止分支污染  ，但是最后加入的这一步往往遗漏，这一步之后也需要剪枝
      in.remove(in.size()-1);
      return ;
    }else{
      dfs(root.left,targetSum,res,in);
      dfs(root.right,targetSum,res,in);
      in.remove(in.size()-1);
      return ;
    }
  }
}
