package algorithm.tree;

import algorithm.tree.inorderTraversal;

import java.util.ArrayList;
import java.util.List;

public class rightSideView {
  public List<Integer> rightSideView(inorderTraversal.TreeNode root) {
    List<Integer> r = new ArrayList<>();
    dfs(root,0,r);
    return r;
  }

  public void dfs(inorderTraversal.TreeNode n,int dept, List<Integer> r ){
    if(n == null)return;
    if(dept==r.size()){
      r.add(n.val);
    }
    dept++;
    dfs(n.right,dept,r);
    dfs(n.left,dept,r);
  }
//  public List<Integer> rightSideView(inorderTraversal.TreeNode root) {
//    Queue<inorderTraversal.TreeNode> q = new LinkedList<>();
//    List<Integer> r = new ArrayList<>();
//    if(root==null)return r;
//    q.offer(root);
//    while (!q.isEmpty()){
//      int size = q.size();
//      for (int i = 0; i < size; i++) {
//        inorderTraversal.TreeNode n = q.poll();
//        if(i==size-1){
//          r.add(n.val);
//        }
//        if(n.left != null){
//          q.offer(n.left);
//        }
//        if(n.right != null){
//          q.offer(n.right);
//        }
//      }
//
//    }
//    return r;
//  }
}
