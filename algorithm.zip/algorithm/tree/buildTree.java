//给定两个整数数组 preorder 和 inorder ，其中 preorder 是二叉树的先序遍历， inorder 是同一棵树的中序遍历，请构造二叉树并
//返回其根节点。
//
//
//
// 示例 1:
//
//
//输入: preorder = [3,9,20,15,7], inorder = [9,3,15,20,7]
//输出: [3,9,20,null,null,15,7]
//
//
// 示例 2:
//
//
//输入: preorder = [-1], inorder = [-1]
//输出: [-1]
//
//
//
//
// 提示:
//
//
// 1 <= preorder.length <= 3000
// inorder.length == preorder.length
// -3000 <= preorder[i], inorder[i] <= 3000
// preorder 和 inorder 均 无重复 元素
// inorder 均出现在 preorder
// preorder 保证 为二叉树的前序遍历序列
// inorder 保证 为二叉树的中序遍历序列
//
// Related Topics 树 数组 哈希表 分治 二叉树
// 👍 1777 👎 0


//leetcode submit region begin(Prohibit modification and deletion)
package algorithm.tree;

import java.util.HashMap;
import java.util.Map;

public class buildTree {
  Map<Integer,Integer> map = new HashMap<>();
  public TreeNode buildTree(int[] inorder, int[] postorder) {
    for (int i = 0; i < inorder.length; i++) {
      map.put(inorder[i],i);
    }
    return back(inorder,postorder,0, postorder.length-1,map,0,postorder.length-1);
  }

  public TreeNode back(int[] inorder, int[] postorder,int l, int r,Map<Integer,Integer> map,int pl, int pr){
    if(l > r || pl > pr) return null;
    TreeNode root= new TreeNode(postorder[pr]);
    int i = map.get(postorder[pr]);

    root.right = back(inorder,postorder,i+1, r,map,pl+i-l,pr-1);
    root.left = back(inorder,postorder,l, i-1,map,pl,pl+i-l-1);
    return root;
  }
//   利用前序遍历的特点得到根节点  然后在中序遍历数组中找到根节点对应的索引 分出来左子树和右子树  这样递归  为了方便获取节点下标，放进map
//  递归退出条件 left>right
  public TreeNode buildTree1(int[] inorder, int[] postorder) {
    for (int i = 0; i < inorder.length; i++) {
      map.put(inorder[i],i);
    }
    return back1(inorder,postorder,0,postorder.length-1,0);
  }
  public TreeNode back1(int[] inorder, int[] postorder,int preleft,int preright,int l_s){
    if(preleft > preright)return null;
    int in_root = map.get(postorder[preleft]);
    TreeNode root = new TreeNode(postorder[preleft]);
    int leftsize = in_root-l_s;
    root.left = back1(inorder,postorder,preleft+1,preleft+leftsize,l_s);
    root.right = back1(inorder,postorder,preleft+leftsize+1,preright,in_root+1);
    return root;
  }
}
