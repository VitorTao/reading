package algorithm.tree;

import java.util.ArrayList;
import java.util.List;
//中序遍历遍历元素是递增的
public class inOrder {
    List<Integer> l = new ArrayList<>();
    public List<Integer>  inOrder(inorderTraversal.TreeNode root) {
        dfs(l,root);
        return l;
    }

    private void dfs(List<Integer> l, inorderTraversal.TreeNode root) {
        if(root==null)return;
        dfs(l,root.left);
        l.add(root.val);
        dfs(l,root.right);
    }
}
