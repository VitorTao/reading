package algorithm.tree;

public class deleteNode {
//    如果 key > root.val，说明要删除的节点在右子树，root.right = deleteNode(root.right, key)。
//    如果 key < root.val，说明要删除的节点在左子树，root.left = deleteNode(root.left, key)。
//    如果 key == root.val，则该节点就是我们要删除的节点，则：
//    如果该节点是叶子节点，则直接删除它：root = null。
//    如果该节点不是叶子节点且有右节点，则用它的后继节点的值替代 root.val = successor.val，然后删除后继节点。
//    如果该节点不是叶子节点且只有左节点，则用它的前驱节点的值替代 root.val = predecessor.val，然后删除前驱节点。
//    返回 root。

    public TreeNode deleteNode(TreeNode root, int key) {
//        递归退出条件
        if(root== null)return null;
        if(key>root.val){
            root.right = deleteNode(root.right,key);
        }
        if(key<root.val){
            root.left = deleteNode(root.left,key);
        }
        if(key==root.val ){
            if(root.left == null && root.right == null ){
                root=null;
            }else if(root.right != null ){
// 先把后继节点换过来，然后再遍历此节点的右子树 因为此时虽然把后继节点的值换到要删除的节点上了，但是后继节点本身还没删除 后继节点身上的孩子还没找好下家
// 所以接着利用递归删除  以当前后继节点的值为key 接着递归删除  什么时候结束呢  为nuLL 的时候
                root.val = successor(root);
                root.right = deleteNode(root.right,root.val);
            }else if(root.left != null){
                root.val = precessor(root);
                root.left = deleteNode(root.left,root.val);
            }
        }

        return root;
    }
//后继节点 代表的是中序遍历序列的下一个节点。即比当前节点大的最小节点，简称后继节点。 先取当前节点的右节点，然后一直取该节点的左节点，直到左节点为空，则最后指向的节点为后继节点
    public int successor(TreeNode root){
        root = root.right;
        while (root.left != null){
            root = root.left;
        }
        return root.val;
    }
//    代表的是中序遍历序列的前一个节点。即比当前节点小的最大节点，简称前驱节点。先取当前节点的左节点，然后取该节点的右节点，直到右节点为空，则最后指向的节点为前驱节点
    public int precessor(TreeNode root){
        root = root.left;
        while (root.right != null){
            root = root.right;
        }
        return root.val;
    }
}
