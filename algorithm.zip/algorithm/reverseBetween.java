package algorithm;

public class reverseBetween {
  public getIntersectionNode.ListNode reverseBetween(getIntersectionNode.ListNode head, int left, int right) {
    getIntersectionNode.ListNode dummy = new getIntersectionNode.ListNode(-1);
    dummy.next = head;
    getIntersectionNode.ListNode pre = dummy;

    for (int i = 0; i < left-1 ; i++) {
      pre = pre.next;
    }
    getIntersectionNode.ListNode cur = pre.next;
    getIntersectionNode.ListNode next = null;
    for (int i = 0; i < (right-left); i++) {
      next = cur.next;
      cur.next = next.next;
      next.next = pre.next;
      pre.next = next;
    }
    return dummy.next;
  }
//  	执行耗时:0 ms,击败了100.00% 的Java用户
//			内存消耗:36 MB,击败了53.52% 的Java用户
//  public getIntersectionNode.ListNode reverseBetween(getIntersectionNode.ListNode head, int left, int right) {
//    getIntersectionNode.ListNode leftpre = null;
//    getIntersectionNode.ListNode rightpost = null;
//    getIntersectionNode.ListNode node = head;
//    getIntersectionNode.ListNode h = head;
//
//    int a = 0;
//    while (h != null) {
//      a++;
//      if (a == left - 1) {
//        leftpre = h;
//      }
//      if (a == right + 1) {
//        rightpost = h;
//      }
//      h = h.next;
//    }
//    getIntersectionNode.ListNode pre = rightpost;
//    getIntersectionNode.ListNode next = null;
//    if(leftpre==null){
//      node = head;
//    }else {
//      node = leftpre.next;
//    }
//    while (node != rightpost) {
//      next = node.next;
//      node.next = pre;
//      pre = node;
//      node = next;
//    }
//    if(leftpre!=null){
//      leftpre.next = pre;
//      return head;
//    }else{
//      return pre;
//    }
//  }
}
