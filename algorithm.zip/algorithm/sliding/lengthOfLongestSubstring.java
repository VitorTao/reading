//给定一个字符串 s ，请你找出其中不含有重复字符的 最长子串 的长度。
//
//
//
// 示例 1:
//
//
//输入: s = "abcabcbb"
//输出: 3
//解释: 因为无重复字符的最长子串是 "abc"，所以其长度为 3。
//
//
// 示例 2:
//
//
//输入: s = "bbbbb"
//输出: 1
//解释: 因为无重复字符的最长子串是 "b"，所以其长度为 1。
//
//
// 示例 3:
//
//
//输入: s = "pwwkew"
//输出: 3
//解释: 因为无重复字符的最长子串是 "wke"，所以其长度为 3。
//     请注意，你的答案必须是 子串 的长度，"pwke" 是一个子序列，不是子串。
//
//
//
//
// 提示：
//
//
// 0 <= s.length <= 5 * 104
// s 由英文字母、数字、符号和空格组成
//
// Related Topics 哈希表 字符串 滑动窗口
// 👍 7316 👎 0
package algorithm.sliding;

import com.fr.third.javax.persistence.criteria.CriteriaBuilder;

import java.util.HashMap;

public class lengthOfLongestSubstring {
//    双指针 遇到重复的就从重复的下一个开始
    public int lengthOfLongestSubstring(String s) {
        HashMap<Character, Integer> map = new HashMap<>();
        int max = 0;
        int start=0;
        for (int end = 0; end < s.length(); end++) {
            Character tmp = s.charAt(end);
//            如果MAP 中有 且大于本次窗口起始位置start 说明本次滑动窗口遇到重复值 更新起始位置   边界条件考虑好
            if(map.getOrDefault(tmp,0)>start){
                start = map.get(tmp);
            }
//            max计算为什么拿出来  假如一直碰不到重复元素 就没法更新最大值了
            max = Math.max(max,(end-start)+1);
            map.put(tmp,end+1);
        }
        return max;
    }
}
