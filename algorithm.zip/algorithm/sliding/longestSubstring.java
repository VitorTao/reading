//给你一个字符串 s 和一个整数 k ，请你找出 s 中的最长子串， 要求该子串中的每一字符出现次数都不少于 k 。返回这一子串的长度。
//
//
//
// 示例 1：
//
//
//输入：s = "aaabb", k = 3
//输出：3
//解释：最长子串为 "aaa" ，其中 'a' 重复了 3 次。
//
//
// 示例 2：
//
//
//输入：s = "ababbc", k = 2
//输出：5
//解释：最长子串为 "ababb" ，其中 'a' 重复了 2 次， 'b' 重复了 3 次。
//
//
//
// 提示：
//
//
// 1 <= s.length <= 104
// s 仅由小写英文字母组成
// 1 <= k <= 105
//
// Related Topics 哈希表 字符串 分治 滑动窗口
// 👍 668 👎 0
package algorithm.sliding;

import java.util.HashMap;
import java.util.Map;
//首先统计所有字母出现的次数，如果都满足要求，直接返回字符串长度，不然，将无法满足的字符拎出来，再用于分割字符串，因为答案中肯定不能包含这些字符，答案只可能存在于这些字符的间隔之中，递归获取被分割的字符串数组，取最大值即可。
public class longestSubstring {
    public int longestSubstring(String s, int k) {
        int max = 0;
        int start = 0;
        Map<Character,Integer> map = new HashMap<>();
        Map<Character,Integer> not = new HashMap<>();
        for (int i = 0; i < s.length() ; i++) {
            char tmp = s.charAt(i);
            map.put(tmp,map.getOrDefault(tmp,0)+1);
        }
        for (Map.Entry<Character,Integer> e:map.entrySet()) {
            if(e.getValue()<k){
                not.put(e.getKey(),0);
            }
        }
        if(not.size()!=0){

        }
        return s.length();
    }
}
