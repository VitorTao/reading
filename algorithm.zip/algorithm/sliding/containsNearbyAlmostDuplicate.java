//给你一个整数数组 nums 和两个整数 k 和 t 。请你判断是否存在 两个不同下标 i 和 j，使得 abs(nums[i] - nums[j]) <=
//t ，同时又满足 abs(i - j) <= k 。
//
// 如果存在则返回 true，不存在返回 false。
//
//
//
// 示例 1：
//
//
//输入：nums = [1,2,3,1], k = 3, t = 0
//输出：true
//
// 示例 2：
//
//
//输入：nums = [1,0,1,1], k = 1, t = 2
//输出：true
//
// 示例 3：
//
//
//输入：nums = [1,5,9,1,5,9], k = 2, t = 3
//输出：false
//
//
//
// 提示：
//
//
// 0 <= nums.length <= 2 * 104
// -231 <= nums[i] <= 231 - 1
// 0 <= k <= 104
// 0 <= t <= 231 - 1
//
// Related Topics 数组 桶排序 有序集合 排序 滑动窗口
// 👍 585 👎 0
package algorithm.sliding;

import java.util.TreeSet;

public class containsNearbyAlmostDuplicate {
//    k 下标
//对于元素 x，当我们希望判断滑动窗口中是否存在某个数 y 落在区间 [x - t, x + t] 中，只需要判断滑动窗口中所有大于等于 x - t 的元素中的最小元素是否小于等于 x + t 即可
// 因为大于等于e—t 的最小值 再去比较 如果最小值都无法满足 <= e+t  那就更不可能存在一个满足的值了
//   利用这种方式  减少很多二次循环遍历查找
    public boolean containsNearbyAlmostDuplicate(int[] nums, int k, int t) {
        int start = 0;
        TreeSet<Long> set = new TreeSet();
        set.add((long)nums[0]);
        for (int i = 1; i < nums.length; i++) {
            //左边界左边的值滑出窗口
            if(i-start>k){
                set.remove((long)nums[start++]);
            }
//            ceiling（e） 找到set中大于等于e的最小值  没有就返回null
            Long ceiling = set.ceiling((long) nums[i] - (long)t);
            if(ceiling!= null && ceiling <= (long)nums[i]+(long)t){
                return true;
            }
            set.add((long)nums[i]);
        }
        return false;
    }
//    超时了
    public boolean containsNearbyAlmostDuplicate1(int[] nums, int k, int t) {
        int start = 0;
        for (int i = 1; i < nums.length; i++) {
            if(Math.abs(i-start)>k){
                start++;
            }
            int tmp = start;
            while (tmp<i){
//                存在int  边界溢出  所以需要用long
                long r = (long)nums[i]-(long)nums[tmp++];
//                System.out.println(r);
                if(Math.abs(r)<=t){
//                    System.out.println(Math.abs(r));
                    return true;
                }
            }
        }
        return false;
    }
}
