package algorithm;

public class lastStoneWeight {
//  堆
  public int lastStoneWeight(int[] stones) {
    int size = stones.length;
    heapinsert(stones);
    while(size>1){
      int first = stones[0];
      swap(stones,0,--size);
      heapify(stones,0,size);
      int sec = stones[0];
      int r = first-sec;
      if(r>0){
        stones[0] = r;
      }else{
        swap(stones,0,--size);
      }
      heapify(stones,0,size);
    }
    return size==0 ?0:stones[0];
  }

  public void heapinsert(int[] stones){

    for (int i = 0; i < stones.length; i++) {
      int cur = i;
      int f = (cur-1)/2;
      while(stones[cur] > stones[f]){
        swap(stones,cur,f);
        cur = f;
        f = (cur-1)/2;
      }
    }
  }

  public void heapify(int[] stones,int i,int size){
    int left = 2*i+1;
    int right = 2*i+2;
    while(left < size){
      int max = left;
      if(right < size && stones[right] > stones[left]){
        max = right;
      }
      if(stones[max] > stones[i]){
        swap(stones,max,i);
      }
      i = max;
      left = 2*i+1;
      right = 2*i+2;
    }
  }

  public void swap(int[] nums, int i, int j) {
    int tmp = nums[i];
    nums[i] = nums[j];
    nums[j] = tmp;
  }

  //  [2,7,4,1,8,1]  [4,3,4,3,2]  动态规划  背包
//  public int lastStoneWeight(int[] stones) {
//    int sum = 0;
//    for (int i = 0; i < stones.length; i++) {
//      sum += stones[i];
//    }
//    int bagweight = sum / 2;
//    int[] dp = new int[bagweight + 1];
//    for (int i = 0; i < stones.length; i++) {
//      for (int j = bagweight; j >= stones[i]; j--) {
//        dp[j] = Math.max(dp[j], dp[j - stones[i]] + stones[i]);
//        System.out.println(dp[j]);
//      }
//    }
//    return Math.abs(sum - dp[bagweight] - dp[bagweight]);
//  }
}
