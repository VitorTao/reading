package algorithm;

public class getLeastNumbers {
  int size;
  int[] heap;
  public int[] getLeastNumbers(int[] arr, int k) {
    if (k == 0) return new int[0];
    heap = new int[k];
    size = k;
    heapinsert(arr);
    return heap;
  }
  public void swap(int[] nums, int i, int j) {
    int tmp = nums[i];
    nums[i] = nums[j];
    nums[j] = tmp;
  }

  public void heapinsert(int[] arr){
    for (int i = 0; i < arr.length; i++) {
      if(i < size){
        int cur = i;
        int f = (cur-1)/2;
        heap[i] = arr[cur];
        while(heap[cur] > heap[f]){
          swap(heap,cur,f);
          cur = f;
          f = (cur-1)/2;
        }
      }else{
        if(arr[i] < heap[0]){
          heap[0] = arr[i];
          heapify(heap,0,size);
        }
      }
    }
  }

  public void heapify(int[] arr ,int i,int size){
    int left = 2*i+1;
    int right = 2*i+2;
    while (left<size){
      int max = left;
      if(right < size && arr[right] > arr[left]){
        max = right;
      }
      if(arr[max] > arr[i]){
        swap(arr,i,max);
      }
      i = max;
      left = 2*i+1;
      right = 2*i+2;
    }
  }
}
