package algorithm;

public class numDecodings {
  public int numDecodings(String s) {
    if (String.valueOf(s.charAt(0)).equals("0")) return 0;
    int[] dp = new int[s.length() + 1];
    dp[0] = 1;
    for (int i = 1; i < s.length(); i++) {
      if(s.charAt(i) == '0'){
        if(s.charAt(i - 1) == '1' || s.charAt(i - 1) == '2'){
          if(i==1){
            dp[i] = 1;
          }else{
            dp[i] = dp[i - 2];
            dp[i+1] = dp[i - 2];
            i++;
          }
        }else{
          return 0;
        }
      }else{
        if(i+1 < s.length() && s.charAt(i + 1) == '0' && (s.charAt(i) == '1' || s.charAt(i) == '2')){
          dp[i] = dp[i - 1];
          dp[i+1] = dp[i - 1];
          i++;
        }else if (Integer.valueOf(s.charAt(i - 1)+""+s.charAt(i)) > 26 || s.charAt(i - 1)=='0' ){
          dp[i] = dp[i - 1];
        }else {
          if(i==1){
            dp[i] = 2;
          }else {
            dp[i] = dp[i - 1] + dp[i - 2];
          }
        }
      }

    }
//    for (int i = 0; i < dp.length; i++) {
//      System.out.println(dp[i]);
//    }
    return dp[s.length()-1];
  }
}
