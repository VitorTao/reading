// LRUCache cache = new LRUCache( 2 /* 缓存容量 */ );
//
//cache.put(1, 1);
//cache.put(2, 2);
//cache.get(1);       // 返回  1
//cache.put(3, 3);    // 该操作会使得密钥 2 作废
//cache.get(2);       // 返回 -1 (未找到)
//cache.put(4, 4);    // 该操作会使得密钥 1 作废
//cache.get(1);       // 返回 -1 (未找到)
//cache.get(3);       // 返回  3
//cache.get(4);       // 返回  4
//
// Related Topics 设计 哈希表 链表 双向链表
package algorithm;

import java.util.HashMap;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class LRUCache {

    HashMap<Integer,Node<Integer,Integer>> map = new HashMap<>();
    myqueue<Integer,Integer> q ;
    public LRUCache(int capacity) {
        q = new myqueue<>(capacity);
    }

    public int get(int key) {
        Node<Integer, Integer> integerIntegerNode = map.get(key);
        if(integerIntegerNode==null){
            return -1;
        }
        q.movetail(integerIntegerNode);
        return integerIntegerNode.val;
    }

    public void put(int key, int value) {
        if(map.containsKey(key)){
            Node<Integer, Integer> integerIntegerNode = map.get(key);
            integerIntegerNode.val = value;
            map.put(key,integerIntegerNode);
            q.movetail(integerIntegerNode);
        }else {
            Node e = new Node(key,value);
            map.put(key,e);
            if(q.cursize>=q.size){
                Node removehead = q.removehead();
                map.remove(removehead.key);
            }
            q.addtotail(e);
        }

    }
}

class Node<K,V>{
    K key;
    V val;
    Node<K,V> pre;
    Node<K,V> next;
    Node(K key,V val){
        this.key = key;
        this.val = val;
    }
    Node(){

    }
}

class myqueue<K,V>{

    int size;
    int cursize;
    Node<K,V> head;
    Node<K,V> tail;
    myqueue(int size){
        this.size = size;
        head = new Node();
        tail = new Node();
        head.next = tail;
        tail.pre = head;
    }

    public void movetail(Node e){
        e.pre.next = e.next;
        e.next.pre = e.pre;
        tail.pre.next = e;
        e.pre = tail.pre;
        e.next = tail;
        tail.pre = e;
    }

    public Node removehead(){
        Node e = head.next;
        head.next = e.next;
        e.next.pre = head;

        e.pre = null;
        e.next = null;
        cursize--;
        return e;
    }

    public void addtotail(Node e){
        tail.pre.next = e;
        e.pre = tail.pre;
        e.next = tail;
        tail.pre = e;
        cursize++;
    }

}
