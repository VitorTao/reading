package algorithm;

import java.util.ArrayList;
import java.util.List;

public class readBinaryWatch {
// 0000 : 010000
//  小时 0-11，分钟 0-59
  static List<String> r = new ArrayList<>();
  public static List<String> readBinaryWatch(int num,int index,int hour,int minu) {
    int[] h = new int[]{1,2,4,8,0,0,0,0,0,0};
    int[] m = new int[]{0,0,0,0,1,2,4,8,16,32};
    if(hour > 11 || minu > 59) return r;
    if(num==0){
      r.add(hour+":"+minu);
      return r;
    }else{
      for (int i = index; i < 10; i++) {
        readBinaryWatch(num-1,i+1,hour+h[i],minu+m[i]);
      }
    }
    return r;
  }
  public static List<String> readBinaryWatch1(int num) {
    if(num==0)return null;
    List<String> r = new ArrayList<>();
    for (int i = 0; i < 12; i++) {
      for (int j = 0; j < 60; j++) {
        if(Integer.bitCount(i)+Integer.bitCount(j)==num){
          r.add(i+":"+j);
        }
      }
    }
    return r;
  }

//  public void backtrack(int num, int index, int hour, int minute){
//    if(hour > 11 || minute > 59)
//      return;
//    if(num == 0){
//      StringBuilder sb = new StringBuilder();
//      sb.append(hour).append(':');
//      if (minute < 10) {
//        sb.append('0');
//      }
//      sb.append(minute);
//      res.add(sb.toString());
//      return;
//    }
//    for(int i = index; i < 10; i++){
//      backtrack(num - 1, i + 1, hour + hours[i], minute + minutes[i]);
//    }
//  }

  public static void main(String[] args) {
//    int a = Integer.parseInt("1000", 2);
//    System.out.println(a);
//    System.out.println(Integer.bitCount(3));
    readBinaryWatch(1,-1,0,0);
  }
}
