package algorithm.backtrack;

import java.util.*;

//给你一个整数数组 nums ，找出并返回所有该数组中不同的递增子序列，递增子序列中 至少有两个元素 。你可以按 任意顺序 返回答案。
//
// 数组中可能含有重复元素，如出现两个整数相等，也可以视作递增序列的一种特殊情况。
//
//
//
// 示例 1：
//
//
//输入：nums = [4,6,7,7]
//输出：[[4,6],[4,6,7],[4,6,7,7],[4,7],[4,7,7],[6,7],[6,7,7],[7,7]]
//
//
// 示例 2：
//
//
//输入：nums = [4,4,3,2,1]
//输出：[[4,4]]
//
//
//
//
// 提示：
//
//
// 1 <= nums.length <= 15
// -100 <= nums[i] <= 100
//
// Related Topics 位运算 数组 哈希表 回溯
// 👍 613 👎 0
public class findSubsequences {
  List<List<Integer>> res = new ArrayList<>();
  List<Integer> in = new ArrayList<>();
  public List<List<Integer>> findSubsequences(int[] nums) {
    back(nums,0);
    return res;
  }
  void back(int[] nums,int s){
    if(in.size()>=2){
      res.add(new ArrayList<>(in));
    }
    // 为什么在回溯体内定义set  set 是本层去重用 本层处理过的元素不在重复处理，为什么没有最后没有对应的remove呢
//   玄机就在回溯本层重新定义一个新的Set  就像threadlocal 一样 树的每个深度遍历(纵向)都使用新的set互不干扰  纵向不受影响
//  树的每层广度遍历（横向）都使用同一个set 保证记录是否使用过某个元素
//   还可以接着优化  数值范围[-100,100]，所以完全可以用数组来做哈希。
//    程序运行的时候对set 频繁的add，set需要做哈希映射（也就是把key通过hash function映射为唯一的哈希值）相对费时间，而且每次重新定义set，add的时候其底层的符号表也要做相应的扩充，也是费事的。
    Set<Integer> set = new HashSet<>();
    for (int i = s; i < nums.length; i++) {
      if(set.contains(nums[i]) || nums[i] < in.get(in.size()-1)){
        continue;
      }
      in.add(nums[i]);
      set.add(nums[i]);
      back(nums,i+1);
      in.remove(in.size()-1);
    }
  }
}
