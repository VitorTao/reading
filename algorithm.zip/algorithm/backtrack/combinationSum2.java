package algorithm.backtrack;
//给定一个候选人编号的集合 candidates 和一个目标数 target ，找出 candidates 中所有可以使数字和为 target 的组合。
//
// candidates 中的每个数字在每个组合中只能使用 一次 。
//
// 注意：解集不能包含重复的组合。
//
//
//
// 示例 1:
//
//
//输入: candidates = [10,1,2,7,6,1,5], target = 8,
//输出:
//[
//[1,1,6],
//[1,2,5],
//[1,7],
//[2,6]
//]
//
// 示例 2:
//
//
//输入: candidates = [2,5,2,1,2], target = 5,
//输出:
//[
//[1,2,2],
//[5]
//]
//
//
//
// 提示:
//
//
// 1 <= candidates.length <= 100
// 1 <= candidates[i] <= 50
// 1 <= target <= 30
//
// Related Topics 数组 回溯
// 👍 1275 👎 0
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class combinationSum2 {
  List<List<Integer>> res = new ArrayList<>();
  List<Integer> in = new ArrayList<>();
  public List<List<Integer>> combinationSum2(int[] candidates, int target) {

//    去重  数组本身有重复 但是结果不许有重复 先排序  前面处理过的数字  后面不再处理
    Arrays.sort(candidates);
    back(candidates,target,0);
    return res;
  }

  public void back(int[] candidates, int target,int i){
    if(target == 0){
      res.add(new ArrayList<>(in));
      return;
    }
    if(i >= candidates.length || target < 0) return;
    for (int j = i; j < candidates.length; j++) {
      // j>i 就是判断是否是同一层分支的依据  把数组想象成一棵树  同一个树枝可以重复 同一层不能重复，因为数组排序后前一个
      // 同一个数据前一层已经处理过一次了 后面相同的数据不需要再处理 j>i 怎么就是同一层了呢
      // 二叉树的层序遍历可以了解   for循环内j++  就相当于前一个树枝已经递归遍历完了，然后开始j++进行下一个树枝
      // j> 起始值i  就说明到了同一层的下一个了
      if(j>i && candidates[j]==candidates[j-1])continue;
      in.add(candidates[j]);
      back(candidates,target-candidates[j],j+1);
      in.remove(in.size()-1);
    }
  }

  public static void main(String[] args) {
    combinationSum2 combinationSum2 = new combinationSum2();
    combinationSum2.combinationSum2(new int[]{10,1,2,7,6,1,5},8);
  }
}
