package algorithm.backtrack;
//给你一个整数数组 nums ，其中可能包含重复元素，请你返回该数组所有可能的子集（幂集）。
//
// 解集 不能 包含重复的子集。返回的解集中，子集可以按 任意顺序 排列。
//
//
//
//
//
// 示例 1：
//
//
//输入：nums = [1,2,2]
//输出：[[],[1],[1,2],[1,2,2],[2],[2,2]]
//
//
// 示例 2：
//
//
//输入：nums = [0]
//输出：[[],[0]]
//
//
//
//
// 提示：
//
//
// 1 <= nums.length <= 10
// -10 <= nums[i] <= 10
//
//
//
// Related Topics 位运算 数组 回溯
// 👍 1049 👎 0
import java.util.*;

//输入：nums = [1,2,2]
//输出：[[],[1],[1,2],[1,2,2],[2],[2,2]]
//
public class subsetsWithDup {
//  public List<List<Integer>> subsetsWithDup(int[] nums) {
//    List<List<Integer>> res = new ArrayList<>();
//    List<Integer> in = new ArrayList<>();
//    Arrays.sort(nums);
//    boolean[] vist = new boolean[nums.length];
//    backtrack(nums,  in,0, res,vist);
//    System.out.println(res);
//    return res;
//  }
////  i其实代表了当前层 一次递归中 i是不会变的   假如同一层中发现当前节点跟上一个节点值一样，就不必再添加，因为上一个节点处理过了，同一路径下相同的节点可以添加
////  每一层刚开始的时候 j=i  所以只要j不等于i的时候就是
////  例如arr = [2,2,3],不去重情况下枚举子集是{[], [2], [2], [3],[2,2],[2,3],[2,3],[2,2,3] },分别编号为1-8吧。当枚举到子集3时，此时的2来自arr[1],对于当前选择的数2(arr[1])，若前面有与其相同的数2(arr[0]),且没有选择2(arr[0])，则包含2(arr[1])的子集{[2]}一定包含于 包含2(arr[0])的所有子集{[2], [2,2],[2,3],[2,2,3]}中。枚举子集7时也是如此
//  public void backtrack(int[] nums,List<Integer> in,int i,List<List<Integer>> res,boolean[] vist){
//    res.add(new ArrayList<>(in));
//    if(i>=nums.length) return;
//    for (int j = i; j <nums.length ; j++) {
//      if(j > 0 && !vist[j-1]  && nums[j] == nums[j-1]){
//        continue;
//      }
//      vist[j] = true;
//      in.add(nums[j]);
//      System.out.println("前"+in);
//      backtrack(nums,  in,j+1, res,vist);
//      in.remove(in.size()-1);
//      vist[j] = false;
//      System.out.println("后"+in);
//    }
//  }
List<List<Integer>> res = new ArrayList<>();
  List<Integer> in = new ArrayList<>();
  public List<List<Integer>> subsetsWithDup(int[] nums) {

    Arrays.sort(nums);
    backtrack(nums,  0);
    System.out.println(res);
    return res;
  }
//  i其实代表了当前层 一次递归中 i是不会变的   假如同一层中发现当前节点跟上一个节点值一样，就不必再添加，因为上一个节点处理过了，同一路径下相同的节点可以添加
//  每一层刚开始的时候 j=i  所以只要j不等于i的时候就是
//  例如arr = [2,2,3],不去重情况下枚举子集是{[], [2], [2], [3],[2,2],[2,3],[2,3],[2,2,3] },分别编号为1-8吧。当枚举到子集3时，此时的2来自arr[1],对于当前选择的数2(arr[1])，若前面有与其相同的数2(arr[0]),且没有选择2(arr[0])，则包含2(arr[1])的子集{[2]}一定包含于 包含2(arr[0])的所有子集{[2], [2,2],[2,3],[2,2,3]}中。枚举子集7时也是如此
  public void backtrack(int[] nums,int s){
    res.add(new ArrayList<>(in));
    if(s>=nums.length) return;
    for (int j = s; j <nums.length ; j++) {
      if(j > s && nums[j] == nums[j-1]){
        continue;
      }
      in.add(nums[j]);
      System.out.println("前"+in);
      backtrack(nums,j+1);
      in.remove(in.size()-1);
      System.out.println("后"+in);
    }
  }
  public static void main(String[] args) {
    subsetsWithDup combinationSum2 = new subsetsWithDup();
    combinationSum2.subsetsWithDup(new int[]{1,2,2,2,2,2,2,3});
  }
}
