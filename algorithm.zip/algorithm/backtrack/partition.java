package algorithm.backtrack;
//给你一个字符串 s，请你将 s 分割成一些子串，使每个子串都是 回文串 。返回 s 所有可能的分割方案。
//
// 回文串 是正着读和反着读都一样的字符串。
//
//
//
// 示例 1：
//
//
//输入：s = "aab"
//输出：[["a","a","b"],["aa","b"]]
//
//
// 示例 2：
//
//
//输入：s = "a"
//输出：[["a"]]
//
//
//
//
// 提示：
//
//
// 1 <= s.length <= 16
// s 仅由小写英文字母组成
//
// Related Topics 字符串 动态规划 回溯
// 👍 1421 👎 0
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class partition {
    List<List<String>> res = new ArrayList<>();
    List<String> in = new ArrayList<>();
    public List<List<String>> partition(String s) {
        backtrack(s,0,in);
        return res;
    }

    public void backtrack(String s, int start, List<String> in){

        if(start>s.length()-1){
            res.add(new ArrayList<>(in));
            return;
        }
        for (int i = start; i < s.length(); i++) {
            if(isPalindrome(s,start,i)){
                String str = s.substring(start,i+1);
                in.add(str);
            }else {
//                想了半天才想明白的是continue那里，因为题目要求按照某种分割方式将主串s分成几个子串全部都是回文串，
//               所以只有某个切割位置可行的时候，才能以此为基础去调用下一层递归去寻找下一个切割位置；若得到的子串不是回文串，
//              则continue往后尝试，直到找到某个可行位置才能调用下一层递归。这样才能避免出现切成的子串出现两个回文夹着一个非回文的情况。
//             2. 因此，能走到终止条件的一定都是一组可行的切割方式，所以直接添加path到结果集中；如以某种分割方式走到某处，一直运行到for循环结束，
//            都找不到回文串，这样就终止在这里了，并不会进入下一层递归，也就进不到那个终止条件，保证了终止条件中添加进结果集的一定都是OK的
                continue;
            }
            backtrack(s,i+1,in);
            in.remove(in.size()-1);
        }
    }

    public boolean isPalindrome(String s,int b,int e){
        while (b<e){
            if(s.charAt(b)!=s.charAt(e)){
                return false;
            }
            b++;
            e--;
        }
        return true;
    }

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("12");
        list.add("23");
        list.add("45");
        String s = "aab";
        System.out.println(list.stream().reduce((x, y) -> x + "." + y).get());
//        System.out.println(s.substring(0,2));
        System.out.println(String.join(".",list));
    }
}
