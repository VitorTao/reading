package algorithm.backtrack;

import java.util.ArrayList;
import java.util.List;

public class generateParenthesis {
    List<String> res = new ArrayList<>();
    public List<String> generateParenthesis(int n) {
        backtrack(n,"",0,0);
        return res;
    }

    public void backtrack(int n,String tmp,int left,int right){
        if(left<right)return;
        if(tmp.length()==n*2){
            res.add(tmp);
            return;
        }
        if(left<n){
            backtrack(n,tmp+"(",left+1,right);
        }
        if(right<n){
            backtrack(n,tmp+")",left,right+1);
        }

    }
}
