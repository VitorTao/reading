package algorithm.backtrack;

import java.util.*;

public class letterCombinations {
  List<String> res = new ArrayList<>();
  public List<String> letterCombinations(String digits) {
    Map<String, List<String>> map = new HashMap<>();
    map.put("2", Arrays.asList("a", "b", "c"));
    map.put("3", Arrays.asList("d", "e", "f"));
    map.put("4", Arrays.asList("g", "h", "i"));
    map.put("5", Arrays.asList("j", "k", "l"));
    map.put("6", Arrays.asList("m", "n", "o"));
    map.put("7", Arrays.asList("p", "q", "r", "s"));
    map.put("8", Arrays.asList("t", "u", "v"));
    map.put("9", Arrays.asList("w", "x", "y", "z"));
    if (digits == null || digits == "" || digits.length() == 0) return res;
    back(digits,map,0,"");
    return res;
  }
  public void back(String digits,Map map,int level,String s){
    if(level==digits.length()){
      res.add(s);
      return;
    }
    List<String> list = (List<String>)map.get(String.valueOf(digits.charAt(level)));
    for (int i = 0; i < list.size(); i++) {
      back(digits,map,level+1,s+list.get(i));
    }
  }

  public static void main(String[] args) {
    letterCombinations l = new letterCombinations();
    List<String> res = l.letterCombinations("23");
    System.out.println(res);
  }
}
