package algorithm.backtrack;

import java.util.ArrayList;
import java.util.List;

public class combinationSum3 {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> in = new ArrayList<>();
    public List<List<Integer>> combinationSum3(int k, int n) {
        backtrack(n,k,1);
        return res;
    }

    private void backtrack(int target, int k, int start) {
        if(target<0)return;
        if(k==0 && target==0){
            res.add((List<Integer>) ((ArrayList<Integer>)in).clone());
            return;
        }
        for (int i = start; i <= 9-k+1; i++) {
            in.add(i);
            backtrack(target-i,k-1,i+1);
//            撤销处理的节点
            in.remove(in.indexOf(i));
        }
    }

//    public List<List<Integer>> combinationSum3(int k, int n) {
//        backtrack(n,k,1);
//        return res;
//    }
//
//    private void backtrack(int n, int k, int start) {
//        if(in.size()==k && n==0){
//            res.add((List<Integer>) ((ArrayList<Integer>)in).clone());
//            return;
//        }
//        for (int i = start; i <= 9; i++) {
//            in.add(i);
//            backtrack(n-i,k,i+1);
////            撤销处理的节点
//            in.remove(in.indexOf(i));
//        }
//    }
}
