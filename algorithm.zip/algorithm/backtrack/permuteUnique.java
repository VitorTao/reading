package algorithm.backtrack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class permuteUnique {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> in = new ArrayList<>();

    public List<List<Integer>> permuteUnique(int[] nums) {
        boolean[] vis = new boolean[nums.length];
        Arrays.fill(vis, false);
        Arrays.sort(nums);
        back(nums, in, vis);
        return res;
    }

    public void back(int[] nums, List<Integer> in, boolean[] vis) {
        if (in.size() == nums.length) {
            res.add(new ArrayList<>(in));
            return;
        }
        for (int j = 0; j < nums.length; j++) {
//            怎么才能去重呢 排过序的数组  当当前值跟上一个值一样  并且上一个访问标记为false  ，说明是同一层有重复不需要再次处理，因为前一个已经访问过 并且置为false了
            if (j>0 &&  nums[j] == nums[j - 1] && !vis[j-1]){
                continue;
            }
//          vis[j] = true  说明此元素已经用过
            if (!vis[j]) {
                vis[j] = true;
                in.add(nums[j]);
                back(nums, in, vis);
                in.remove(in.size() - 1);
                vis[j] = false;
            }
        }
    }

//    List<List<Integer>> res = new ArrayList<>();
//    List<Integer> in = new ArrayList<>();
//    int[] use ;
//    public List<List<Integer>> permuteUnique(int[] nums) {
//        Arrays.sort(nums);
//        use = new int[nums.length];
//        back(nums);
//        return res;
//    }
//
//    void back(int[] nums) {
//        if (in.size() == nums.length) {
//            res.add(new ArrayList<>(in));
//            return;
//        }
//
//        for (int i = 0; i < nums.length; i++) {
//            // use[i-1] == 1 说明同一树枝nums[i-1]使用过
//            // use[i-1] == 0 说明同一树层nums[i-1]使用过
//            if (use[i] == 1 ||(i>0 && use[i-1] == 0 && nums[i] == nums[i-1])) {
//                continue;
//            }
//            in.add(nums[i]);
//            use[i] = 1;
//            back(nums);
//            in.remove(in.size() - 1);
//            use[i] = 0;
//        }
//    }
}
