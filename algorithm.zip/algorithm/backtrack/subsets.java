package algorithm.backtrack;
//给你一个整数数组 nums ，数组中的元素 互不相同 。返回该数组所有可能的子集（幂集）。
//
// 解集 不能 包含重复的子集。你可以按 任意顺序 返回解集。
//
//
//
// 示例 1：
//
//
//输入：nums = [1,2,3]
//输出：[[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]
//
//
// 示例 2：
//
//
//输入：nums = [0]
//输出：[[],[0]]
//
//
//
//
// 提示：
//
//
// 1 <= nums.length <= 10
// -10 <= nums[i] <= 10
// nums 中的所有元素 互不相同
//
// Related Topics 位运算 数组 回溯
// 👍 1963 👎 0
import java.util.ArrayList;
import java.util.List;

public class subsets {
  List<List<Integer>> res = new ArrayList<>();
  List<Integer> in = new ArrayList<>();
  public List<List<Integer>> subsets(int[] nums) {
    backtrack(nums,0,in);
    return res;
  }
  public void backtrack(int[] nums,int start,List<Integer> in){
//    等同于获取树的所有节点
    res.add(new ArrayList<>(in));
    if(start>nums.length-1){
      return;
    }
    for (int i = start; i < nums.length; i++) {
//      []
//				[1]
//				[1, 2]
//				[1, 2, 3]
//				[1, 3]
//				[2]
//				[2, 3]
//				[3]
//      画个图容易理解  每一层结束会把上一层的最后一个remove 当从1开始深度遍历到3的时候 3 包含3返回后就remove 3 之后remove 2 然后再从 第三个3 开始
//      此时是1 3 的格局 当最后一个3 结束时 返回也会remove 上一层的最后一个 1  此时开始从2 遍历
      System.out.println(in.toString());
      in.add(nums[i]);
      backtrack(nums,i+1,in);
//            撤销处理的节点
      in.remove(in.size()-1);
    }
  }
  public static void main(String[] args) {
    subsets combinationSum2 = new subsets();
    combinationSum2.subsets(new int[]{1,2,3});
  }
}
