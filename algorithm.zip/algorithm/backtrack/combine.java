package algorithm.backtrack;//给定两个整数 n 和 k，返回范围 [1, n] 中所有可能的 k 个数的组合。
//
// 你可以按 任何顺序 返回答案。
//
//
//
// 示例 1：
//
//
//输入：n = 4, k = 2
//输出：
//[
//  [2,4],
//  [3,4],
//  [2,3],
//  [1,2],
//  [1,3],
//  [1,4],
//]
//
// 示例 2：
//
//
//输入：n = 1, k = 1
//输出：[[1]]
//
//
//
// 提示：
//
//
// 1 <= n <= 20
// 1 <= k <= n
//
// Related Topics 数组 回溯
// 👍 862 👎 0



import com.fr.third.org.apache.poi.hssf.record.formula.functions.Int;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

//leetcode submit region begin(Prohibit modification and deletion)
class combine {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> in = new ArrayList<>();
    public List<List<Integer>> combine(int n, int k) {
        backtrack(n,1,k);
        return res;
    }

    public void backtrack(int n,int start,int k){
        if(in.size()==k){
            res.add((List<Integer>) ((ArrayList<Integer>)in).clone());
            return;
        }
        for (int i = start; i <= n; i++) {
//            剪枝
            if(n-i+1<k-in.size())break;
            in.add(i);
            backtrack(n,i+1,k);
//            撤销处理的节点
            in.remove(in.indexOf(i));
        }
    }

    public static void main(String[] args) {
        List<List<Integer>> res = new ArrayList<>();
        List<Integer> l = new ArrayList<>();
        l.add(3);
        l.add(4);
//        res.add( l.clone());
        System.out.println(l.remove(l.indexOf(3)));
        System.out.println(res);
    }
}
//leetcode submit region end(Prohibit modification and deletion)
