package algorithm.backtrack;

import java.util.ArrayList;
import java.util.List;

public class permute {
  List<List<Integer>> res = new ArrayList<>();
  List<Integer> in = new ArrayList<>();
  public List<List<Integer>> permute(int[] nums) {
    back(nums,  in);
    return res;
  }

  public void back(int[] nums, List<Integer> in) {
    if (in.size() == nums.length) {
      res.add(new ArrayList<>(in));
      return;
    }
    for (int j = 0; j < nums.length; j++) {
      if (!in.contains(nums[j])) {
        in.add(nums[j]);
        back(nums, in);
        in.remove(in.size() - 1);
      }
    }

  }

//  int[] use ;
//  public List<List<Integer>> permute(int[] nums) {
//    use = new int[nums.length]
//    back(nums);
//    return res;
//  }
//
//  void back(int[] nums) {
//    if (in.size() == nums.length) {
//      res.add(new ArrayList<>(in));
//      return;
//    }
//    for (int i = 0; i < nums.length; i++) {
//      if(use[nums[i]]==1){
//        continue;
//      }
//      in.add(nums[i]);
//      use[nums[i]] = 1;
//      back(nums);
//      in.remove(in.size() - 1);
//      use[nums[i]] = 0;
//    }
//  }
}
