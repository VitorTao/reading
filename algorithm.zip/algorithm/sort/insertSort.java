package algorithm.sort;


public class insertSort {
//  static int[] nums = new int[]{8,8,8,8,8,8,8,8};
  static int[] nums = new int[]{3,1,8,5,7,2,9};
  
  public static void insertSort(){
    int len = nums.length;
    for (int i = 1; i < len ; i++) {
      int num = nums[i];
      for (int j = i-1; j >= 0 ; j--) {
        if(nums[j] > num){
          swap(j,j+1);
        }
      }
    }

  }
  
  
  
  public static void test(){
    for (int i = 1; i < nums.length; i++) {
      int j = i;
      while (j>0 && nums[j-1] > nums[j]){
          swap(j,j-1);
          j--;
      }
    }
  }
  

  public static void main(String[] args) {
//    for (int i = 1; i < nums.length; i++) {
//      int j = i - 1;
//      int tmp = nums[i];
//      while (j >= 0 && nums[j] > tmp) {
//        swap(j, j+1);
//        j--;
//      }
//    }
    insertSort();
    for (int i = 0; i < nums.length; i++) {
      System.out.println(nums[i]);
    }
  }
  public static void swap(int l,int r){
    int tmp = nums[l];
    nums[l] = nums[r];
    nums[r] = tmp;
  }
}
