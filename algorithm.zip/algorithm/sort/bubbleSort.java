package algorithm.sort;

import java.util.Arrays;

public class bubbleSort {
  static int[] nums = new int[]{3,1,8,5,7,2,9};
  public static void main(String[] args) {

    int len = nums.length;
    for (int i = 0; i < len; i++) {
      for (int j = 0; j < len-i-1; j++) {
        if(nums[j] > nums[j+1]){
          swap(j,j+1);
        }
      }
    }
//    Arrays.asList(nums).forEach(j -> System.out.println(j));
    for (int i = 0; i < len; i++) {
      System.out.println(nums[i]);
    }
  }

  public static void swap(int l,int r){
    int tmp = nums[l];
    nums[l] = nums[r];
    nums[r] = tmp;
  }

}
