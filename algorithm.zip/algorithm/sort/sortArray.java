//给你一个整数数组 nums，请你将该数组升序排列。
//
//
//
//
//
//
// 示例 1：
//
//
//输入：nums = [5,2,3,1]
//输出：[1,2,3,5]
//
//
// 示例 2：
//
//
//输入：nums = [5,1,1,2,0,0]
//输出：[0,0,1,1,2,5]
//
//
//
//
// 提示：
//
//
// 1 <= nums.length <= 5 * 104
// -5 * 104 <= nums[i] <= 5 * 104
//
// Related Topics 数组 分治 桶排序 计数排序 基数排序 排序 堆（优先队列） 归并排序
// 👍 512 👎 0
package algorithm.sort;

public class sortArray {
    //    insertsort  插入  将一个数字插入一个有序的数组」这一步，可以不使用逐步交换，使用先赋值给「临时变量」，然后「适当的元素」后移，空出一个位置，最后把「临时变量」赋值给这个空位的策略（就是上面那张图的意思）
    public int[] insertsortArray(int[] nums) {
        int n = nums.length;
        for (int i = 1; i < n; i++) {
            int tmp = nums[i];
            int j = i;
            while (j > 0 && nums[j - 1] > tmp) {
//                往后挪一位
                nums[j] = nums[j - 1];
                j--;
            }
            nums[j] = tmp;
        }
        return nums;
    }

    public int[] quick(int[] nums) {
        int n = nums.length;
        partition(nums,0,n-1);
        return nums;
    }
//从后向前找到一个小于基准值的  交换  然后从前向后找到大于基准值的交换
    private void partition(int[] nums, int l, int r) {
        if(l>=r) return;
        int l1 = l;
        int r1 = r;
        int tmp = nums[l];
        while (l<r){
            while (nums[r]>tmp) {
                r--;
            }
            swap(nums,l,r);
            while (nums[l]<tmp) {
                l++;
            }
            swap(nums,l,r);
        }
        partition(nums,l1,l-1);
        partition(nums,l+1,r1);
    }

    public void swap(int[] nums, int i, int j) {
        int tmp = nums[i];
        nums[i] = nums[j];
        nums[j] = tmp;
    }
}
