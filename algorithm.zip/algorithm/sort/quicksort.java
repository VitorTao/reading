package algorithm.sort;

public class quicksort {




  public static void main(String[] args) {
//    int[] a = new int[]{3,1,5,4,7,90,2};
    int[] a = new int[]{1,0,-1,0,-2,2};
    quicksort q = new quicksort();
//    q.quicksort(a,0,a.length-1);
    q.quickdemo(a,0,a.length-1);
    for (int i = 0; i < a.length; i++) {
      System.out.println(a[i]);
    }
  }

  public void quickdemo(int[] a,int l,int r){
    //    退出条件
    if(l>=r)return;
//    单独拿出来进行比较，防止下标改变
    int base = a[l];
    int left = l;
    int right = r;

    while (left < right){
//      right>left  临界条件
      while (right>left && a[right] >= base){
        right--;
      }
      a[left] = a[right];
      while (left < right && a[left] < base){
        left++;
      }
      a[right] = a[left];
    }
    a[left] = base;
    quickdemo(a,l,left-1);
    quickdemo(a,left+1,r);
  }
}
