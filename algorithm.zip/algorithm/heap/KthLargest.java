package algorithm.heap;

public class KthLargest {

  int[] heap;
  int size;
  public KthLargest(int k, int[] nums) {
    heap = new int[k];
    size = k;
    heapinsert(k, nums);
  }

  public void swap(int[] nums, int i, int j) {
    int tmp = nums[i];
    nums[i] = nums[j];
    nums[j] = tmp;
  }

  public void heapinsert(int k, int[] nums) {
    for (int i = 0; i < nums.length; i++) {
      int cur = i;
      int f = (cur - 1) / 2;
      if (cur < k) {
        heap[cur] = nums[cur];
        while (heap[f] > heap[cur]) {
          swap(heap, f, cur);
          cur = f;
          f = (cur - 1) / 2;
        }
      } else if (nums[cur] > nums[0]) {
        swap(heap,0,cur);
        heapify(heap, 0, k);
      }
    }
  }

  public void heapify(int[] nums, int i, int size) {
    int left = i * 2 + 1;
    int right = i * 2 + 2;
    while (left < size) {
      int min = left;
      if (right < size && nums[right] < nums[left]) {
        min = right;
      }
      if (nums[i] > nums[min]) {
        swap(nums, i, min);
        i = min;
        left = i * 2 + 1;
        right = i * 2 + 2;
      } else {
        break;
      }
    }
  }

  public int add(int val) {
    if(val > heap[0]){
      heap[0]=val;
      heapify(heap, 0, size);
    }
    return heap[0];
  }

  public static void main(String[] args) {
    int[] heap1 = new int[5];
    System.out.println(heap1.length);
  }
}
