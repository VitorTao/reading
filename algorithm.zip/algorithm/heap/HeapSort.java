package algorithm.heap;

public class HeapSort {

  public static void main(String[] args) {
//    System.out.println((0-1)/2); == 0  遍历  发现自己比父节点大就交换  初始化一个堆
    int[] a = new int[]{5, 2, 3, 1, 4};
    for (int j = 0; j < a.length; j++) {
      int cur = j;
      int f = (cur - 1) / 2;
      while (a[cur] > a[f]) {
        swap(a, f, cur);
        cur = f;
        f = (cur - 1) / 2;
      }
    }

    int i = a.length - 1;
//    每次交换第一个跟最后一个节点  然后进行堆化调整
    while (i > 0) {
      swap(a, 0, i--);
      heapfy(a, 0, i);
    }
    for (int j = 0; j < a.length; j++) {
      System.out.println(a[j]);
    }
  }

  public static void swap(int[] nums, int i, int j) {
    int tmp = nums[i];
    nums[i] = nums[j];
    nums[j] = tmp;
  }

  public static void heapfy(int[] nums, int cur, int size) {
    int left = cur * 2 + 1;
    int right = cur * 2 + 2;
    while (left <= size) {
      int max = left;
      if (right <= size && nums[left] < nums[right]) {
        max = right;
      }
      if (nums[max] > nums[cur]) {
        swap(nums, max, cur);
        cur = max;
        left = cur * 2 + 1;
        right = cur * 2 + 2;
      }else{
        break;
      }
    }

  }
}
