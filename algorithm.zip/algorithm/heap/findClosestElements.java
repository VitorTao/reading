//给定一个 排序好 的数组 arr ，两个整数 k 和 x ，从数组中找到最靠近 x（两数之差最小）的 k 个数。返回的结果必须要是按升序排好的。
//
// 整数 a 比整数 b 更接近 x 需要满足：
//
//
// |a - x| < |b - x| 或者
// |a - x| == |b - x| 且 a < b
//
//
//
//
// 示例 1：
//
//
//输入：arr = [1,2,3,4,5], k = 4, x = 3
//输出：[1,2,3,4]
//
//
// 示例 2：
//
//
//输入：arr = [1,2,3,4,5], k = 4, x = -1
//输出：[1,2,3,4]
//
//
//
//
// 提示：
//
//
// 1 <= k <= arr.length
// 1 <= arr.length <= 104
// arr 按 升序 排列
// -104 <= arr[i], x <= 104
//
// Related Topics 数组 双指针 二分查找 排序 堆（优先队列）
// 👍 305 👎 0
package algorithm.heap;

import java.util.*;

public class findClosestElements {
    //    离x近的建堆 找出K个
    int[][] heap;

    public List<Integer> findClosestElements(int[] arr, int k, int x) {
        heap = new int[arr.length][2];
        for (int i = 0; i < arr.length; i++) {
            heap[i][0] = arr[i];
            heap[i][1] = Math.abs(arr[i] - x);
        }
        for (int i = 0; i < heap.length; i++) {
            int cur = i;
            int f = (cur - 1) / 2;
            while (heap[cur][1] > heap[f][1] || (heap[cur][1] == heap[f][1] && heap[cur][0] > heap[f][0])) {
                swap(cur, f);
                cur = f;
                f = (cur - 1) / 2;
            }
        }

        int n = heap.length - 1;
        while (n > 0) {
            swap(0, n);
            heapify(0, --n);
        }
//        for (int i = 0; i < heap.length; i++) {
//            System.out.println(heap[i][0] + "=" + heap[i][1]);
//        }
        List<Integer> res = new ArrayList<>();
        for (int i = 0; i < Math.min(k, heap.length); i++) {
            res.add(heap[i][0]);
        }
        Collections.sort(res);
        return res;
    }

    private void heapify(int cur, int size) {
        int l = cur * 2 + 1;
        int r = cur * 2 + 2;
        while (l <= size) {
            int max = l;
            if (r <= size && (heap[r][1] > heap[l][1] || (heap[l][1] == heap[r][1] && heap[l][0] < heap[r][0]))) {
                max = r;
            }
            if (heap[max][1] > heap[cur][1] || (heap[max][1] == heap[cur][1] && heap[cur][0] < heap[max][0])) {
                swap(max, cur);
                cur = max;
                l = cur * 2 + 1;
                r = cur * 2 + 2;
            } else {
                break;
            }
        }
    }

    public void swap(int i, int j) {
        int[] tmp = heap[i];
        heap[i] = heap[j];
        heap[j] = tmp;
    }
}
