//给定一个单词列表 words 和一个整数 k ，返回前 k 个出现次数最多的单词。
//
// 返回的答案应该按单词出现频率由高到低排序。如果不同的单词有相同出现频率， 按字典顺序 排序。
//
//
//
// 示例 1：
//
//
//输入: words = ["i", "love", "leetcode", "i", "love", "coding"], k = 2
//输出: ["i", "love"]
//解析: "i" 和 "love" 为出现次数最多的两个单词，均为2次。
//    注意，按字母顺序 "i" 在 "love" 之前。
//
//
// 示例 2：
//
//
//输入: ["the", "day", "is", "sunny", "the", "the", "the", "sunny", "is", "is"], k
// = 4
//输出: ["the", "is", "sunny", "day"]
//解析: "the", "is", "sunny" 和 "day" 是出现次数最多的四个单词，
//    出现次数依次为 4, 3, 2 和 1 次。
//
//
//
//
// 注意：
//
//
// 1 <= words.length <= 500
// 1 <= words[i] <= 10
// words[i] 由小写英文字母组成。
// k 的取值范围是 [1, 不同 words[i] 的数量]
//
//
//
//
// 进阶：尝试以 O(n log k) 时间复杂度和 O(n) 空间复杂度解决。
// Related Topics 字典树 哈希表 字符串 桶排序 计数 排序 堆（优先队列）
// 👍 441 👎 0
package algorithm.heap;

import com.fr.third.org.redisson.misc.Hash;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//s1.compareTo(s2)>0 说明s1>s2  s1 在s2 后面  应该放在小根堆顶
public class topKFrequenString {
    Map.Entry<String, Integer>[] heap;

    public List<String> topKFrequent(String[] words, int k) {
        HashMap<String, Integer> map = new HashMap<>();
        List<String> res = new ArrayList<>();
        for (int i = 0; i < words.length; i++) {
            map.put(words[i], map.getOrDefault(words[i],0) + 1);
        }
        heap = new Map.Entry[map.size()];
        int i = 0;
        for (Map.Entry<String, Integer> e : map.entrySet()) {
            heap[i++] = e;
        }
        for (int j = 0; j < heap.length; j++) {
            int cur = j;
            int f = (cur - 1) / 2;
            while (heap[cur].getValue() < heap[f].getValue() || (heap[cur].getValue() == heap[f].getValue() && heap[cur].getKey().compareTo(heap[f].getKey()) > 0)) {
                swap(cur, f);
                cur = f;
                f = (cur - 1) / 2;
            }
        }
        int n = heap.length - 1;
        while (n > 0) {
            swap(0, n);
            heapify(0, --n);
        }
        for (int j = 0; j < k; j++) {
            res.add(heap[j].getKey());
        }
        return res;
    }

    private void heapify(int cur, int size) {
        int l = cur * 2 + 1;
        int r = cur * 2 + 2;
        while (l <= size) {
            int min = l;
            if (r <= size && (heap[r].getValue() < heap[l].getValue() || (heap[r].getValue() == heap[l].getValue() && heap[r].getKey().compareTo(heap[l].getKey()) > 0))) {
                min = r;
            }
            if (heap[cur].getValue() > heap[min].getValue() || (heap[cur].getValue() == heap[min].getValue() && heap[cur].getKey().compareTo(heap[min].getKey()) < 0)) {
                swap(cur, min);
                cur = min;
                l = cur * 2 + 1;
                r = cur * 2 + 2;
            } else {
                break;
            }

        }
    }

    public void swap(int i, int j) {
        Map.Entry<String, Integer> tmp = heap[i];
        heap[i] = heap[j];
        heap[j] = tmp;
    }
}
