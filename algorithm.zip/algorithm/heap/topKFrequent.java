package algorithm.heap;

import com.alibaba.druid.support.profile.ProfileEntryStatValue;

import java.util.HashMap;
import java.util.Map;

public class topKFrequent {
    Map.Entry<Integer, Integer>[] heap ;
    public int[] topKFrequent(int[] nums, int k) {
        HashMap<Integer,Integer> map = new HashMap<>();
        heap = new Map.Entry[k];
        int[] res = new int[k];
        for (int i = 0; i < nums.length; i++) {
            int index = i;
            if(map.containsKey(nums[i])){
                map.put(nums[i],map.get(nums[i])+1);
            }else {
                map.put(nums[i],1);
            }
        }
        insertheap(map,0,k);
        for (int i = 0; i < heap.length; i++) {
            res[i] = heap[i].getKey();
        }
        return res;
    }

    private void insertheap(HashMap<Integer, Integer> map, int i, int k) {
        int cur = 0;

        for (Map.Entry<Integer, Integer> entry : map.entrySet())  {
            if(cur<k){
                int f = (cur-1)/2;
                heap[cur] = entry;
                while (entry.getValue()<heap[f].getValue()){
                    swap(heap,cur,f);
                    cur = f;
                    f = (cur-1)/2;
                }

            }else if(entry.getValue()>heap[0].getValue()){
                heap[0] = entry;
                heapify(heap,0,k);
            }
            cur++;
        }

    }

    private void heapify(Map.Entry<Integer, Integer>[] heap, int i, int k) {
        int l = i*2+1;
        int r = i*2+2;
        while (l<k){
            int min = l;
            if(r<k && heap[l].getValue()>heap[r].getValue()){
                min = r;
            }
            if(heap[min].getValue()<heap[i].getValue()){
                swap(heap,min,i);
                i = min;
                l = i*2+1;
                r = i*2+2;
            }else {
                break;
            }

        }
    }

    public void swap(Map.Entry[] heap,int i,int j){
        Map.Entry tmp = heap[i];
        heap[i] = heap[j];
        heap[j] = tmp;
    }

//    public int[] topKFrequent(int[] nums, int k) {
//        HashMap<Integer,Integer> map = new HashMap<>();
//        int[][] a ;
//        for (int i = 0; i < nums.length; i++) {
//            map.put(words[i], map.getOrDefault(nums[i],0) + 1);
//        }
//        a = new int[map.size()][2];
//        int i = 0;
//        for (Map.Entry<Integer,Integer> e:map.entrySet()) {
//            a[i][0] = e.getKey();
//            a[i][1] = e.getValue();
//            i++;
//        }
//        for (int j = 0; j < a.length; j++) {
//            int tmp = j;
//            int f = (tmp-1)/2;
//            while (a[tmp][1]<a[f][1]){
//                swap(a,tmp,f);
//                tmp = f;
//                f = (tmp-1)/2;
//            }
//        }
//
//        int n  = a.length-1;
//        while (n>0){
//            swap(a,0,n);
//            heapify(a,0,--n);
//        }
//        int[] res = new int[k];
//        for (int j = 0; j < k; j++) {
//            res[j] = a[j][0];
//        }
//        return res;
//    }
//    public void heapify(int[][] a, int cur, int j){
//        int l = cur*2+1;
//        int r = cur*2+2;
//        while (l<=j){
//            int min = l;
//            if(r <= j && a[r][1] < a[l][1]){
//                min = r;
//            }
//            if(a[min][1] < a[cur][1]){
//                swap(a,min,cur);
//                cur = min;
//                l = cur*2+1;
//                r = cur*2+2;
//            }else {
//                break;
//            }
//        }
//    }
//    public static void swap(int[][] nums, int i, int j) {
//        int[] tmp = nums[i];
//        nums[i] = nums[j];
//        nums[j] = tmp;
//    }
}
