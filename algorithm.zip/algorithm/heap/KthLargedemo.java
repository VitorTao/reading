package algorithm.heap;

// 最小堆用来找第K大  最大堆用来找第K小 假如是找第K大 K个元素的最小堆 保证这K个元素是数组里面的前K大，
//只有这样 堆顶才是第K大 所以先创建K个最小堆 接着进来一个跟堆顶比较 比堆顶大就放进来，因为整个堆是前K大的值，所以要找前K大的值 小的就扔出去
public class KthLargedemo {


  public static void heapfy(int[] nums, int i, int size) {
    int cur = i;
    int l = cur*2+1;
    int r = cur*2+2;
    while (cur < size){
      if(l>=size)return;
      int min = l;
      if(r < size && nums[l] > nums[r]){
        min = r;
      }
      if(nums[min] < nums[cur]){
        swap(nums,cur,min);
      }
      cur = min;
      l = cur*2+1;
      r = cur*2+2;
    }
  }

  public static void swap(int[] nums, int i, int j) {
    int tmp = nums[i];
    nums[i] = nums[j];
    nums[j] = tmp;
  }

  public static void main(String[] args) {
    int[] nums = {-1,2,0};
    int k = 2;
    for (int i = 0; i < nums.length; i++) {
//      如果堆中还没到K个值 先初始化堆
      if(i<k){
        int cur = i;
        int parent = (cur-1)/2;
        while (nums[parent] > nums[cur]){
          swap(nums,cur,parent);
          cur = parent;
          parent = (cur-1)/2;
        }
      }else if(nums[i] > nums[0]){ // 如果已经有个K最小堆 就替换根节点 然后调整堆  最终这个K是数组里面前K大的值
        swap(nums,0,i);
        heapfy(nums,0,k);
      }
    }
  }
}

