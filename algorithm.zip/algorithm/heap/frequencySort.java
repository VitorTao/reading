//给定一个字符串 s ，根据字符出现的 频率 对其进行 降序排序 。一个字符出现的 频率 是它出现在字符串中的次数。
//
// 返回 已排序的字符串 。如果有多个答案，返回其中任何一个。
//
//
//
// 示例 1:
//
//
//输入: s = "tree"
//输出: "eert"
//解释: 'e'出现两次，'r'和't'都只出现一次。
//因此'e'必须出现在'r'和't'之前。此外，"eetr"也是一个有效的答案。
//
//
// 示例 2:
//
//
//输入: s = "cccaaa"
//输出: "cccaaa"
//解释: 'c'和'a'都出现三次。此外，"aaaccc"也是有效的答案。
//注意"cacaca"是不正确的，因为相同的字母必须放在一起。
//
//
// 示例 3:
//
//
//输入: s = "Aabb"
//输出: "bbAa"
//解释: 此外，"bbaA"也是一个有效的答案，但"Aabb"是不正确的。
//注意'A'和'a'被认为是两种不同的字符。
//
//
//
//
// 提示:
//
//
// 1 <= s.length <= 5 * 105
// s 由大小写英文字母和数字组成
//
// Related Topics 哈希表 字符串 桶排序 计数 排序 堆（优先队列）
// 👍 381 👎 0
package algorithm.heap;

import java.util.HashMap;
import java.util.Map;

public class frequencySort {
    Map.Entry<Character,Integer>[] heap;
    public String frequencySort(String s) {
        HashMap<Character,Integer> map = new HashMap<>();
        for (int i = 0; i < s.length(); i++) {
            map.put(s.charAt(i),map.getOrDefault(s.charAt(i),0)+1);
        }
        heap = new Map.Entry[map.size()];
        int i=0;
        for (Map.Entry e:map.entrySet()) {
            heap[i++] = e;
        }
        for (int j = 0; j < heap.length; j++) {
            int cur = j;
            int f = (cur-1)/2;
            while (heap[cur].getValue()<heap[f].getValue()){
                swap(cur,f);
                cur = f;
                f = (cur-1)/2;
            }
        }
        int n = heap.length-1;
        while (n>0){
            swap(0,n);
            heapify(0,--n);
        }
        StringBuilder res = new StringBuilder();
        for (int j = 0; j < heap.length; j++) {
            Integer count = heap[j].getValue();
            Character key = heap[j].getKey();
            for (int k = 0; k < count; k++) {
                res.append(key);
            }
        }
        return res.toString();

    }

    public void heapify(int cur,int size){
        int l = cur*2+1;
        int r = cur*2+2;
        while (l<=size){
            int min = l;
            if(r<=size && heap[r].getValue()<heap[l].getValue()){
                min = r;
            }
            if(heap[min].getValue()<heap[cur].getValue()){
                swap(min,cur);
                cur = min;
                l = cur*2+1;
                r = cur*2+2;
            }else {
                break;
            }
        }
    }
    public void swap(int i, int j) {
        Map.Entry<Character, Integer> tmp = heap[i];
        heap[i] = heap[j];
        heap[j] = tmp;
    }
}
