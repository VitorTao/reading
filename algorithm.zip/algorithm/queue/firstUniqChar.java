package algorithm.queue;

import javafx.util.Pair;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

public class firstUniqChar {
  public int firstUniqChar(String s) {
    Map<Character,Integer> map = new HashMap<>();
    for (int i = 0; i < s.length(); i++) {
      if(map.get(s.charAt(i))==null){
        map.put(s.charAt(i),i);
      }else{
        map.put(s.charAt(i),-1);
      }
    }
    int first = s.length();
    for (Map.Entry<Character, Integer> entry : map.entrySet()) {
      int pos = entry.getValue();
      if (pos != -1 && pos < first) {
        first = pos;
      }
    }
    if(first == s.length()){
      return -1;
    }
    return first;
  }

//  public int firstUniqChar(String s) {
//    Queue<Pair<Character,Integer>> q = new LinkedList<>();
//    Map<Character, Integer> map = new HashMap<>();
//    for (int i = 0; i < s.length(); i++) {
//      if (map.get(s.charAt(i)) == null) {
//        map.put(s.charAt(i), i);
//        q.add(new Pair<>(s.charAt(i), i));
//      } else {
//        map.put(s.charAt(i), -1);
//        while (map.get(q.peek().getKey()) == -1) {
//          q.poll();
//        }
//
//      }
//    }
//    return q.peek().getValue();
//  }
}
