package algorithm;

import java.util.ArrayList;
import java.util.List;

public class NBTPreorder {
  List<Integer> r = new ArrayList<>();
  public List<Integer> preorder(NBTMaxDepth.Node root) {

    if(root == null) return r;
    r.add(root.val);
    for (int i = 0; i < root.children.size(); i++) {
      preorder(root.children.get(i));
    }

    return r;
  }
}
