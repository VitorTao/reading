package algorithm.recursion;

public class isPowerOfTwo {
    public boolean isPowerOfTwo(int n) {
//        任何一个数的 0 次方都是 1，所以在 n = 1 的情况下，n 也是 2 的幂。 而在 n 为 2的倍数时，就可以进行自己调用自己的操作了。
        if(n<1)return false;
        if(n==1)return true;
        if(n%2==1) return false;
        return isPowerOfTwo(n/2);
    }
}
