package algorithm;

/**
 * Definition for singly-linked list.
 * public class ListNode {
 * int val;
 * ListNode next;
 * ListNode(int x) {
 * val = x;
 * next = null;
 * }
 * }
 */
public class getIntersectionNode {
  //  headA  headB  同时走  谁先到结尾就赋值到对方的头节点继续走 ，这样如果相交的话就是第一个交点 ，就像两个沙漏计时一样那种技巧，短的和长的都走完此时的差值就是共同长度的起点
//  执行耗时:2 ms,击败了26.99% 的Java用户
//			内存消耗:41.3 MB,击败了35.73% 的Java用户
  public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
    ListNode ha = headA;
    ListNode hb = headB;
    int a = 0;
    if(ha == null || hb == null)return null;
    while (ha != null || hb != null) {
      if(ha == null){
        a++;
        ha = headB;
      }
      if(hb==null){
        a++;
        hb = headA;
      }
      if(ha == hb){
        return ha;
      }
      if(a>2)return null;
      ha = ha.next;
      hb = hb.next;
    }
    return null;
  }
//  执行耗时:1 ms,击败了100.00% 的Java用户
//			内存消耗:41.3 MB,击败了47.26% 的Java用户
//  public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
//    int a=0;
//    int b=0;
//    ListNode ha = headA;
//    ListNode hb = headB;
//    while (ha!=null){
//      a++;
//      ha = ha.next;
//    }
//    while (hb!=null){
//      b++;
//      hb = hb.next;
//    }
//    if(a > b){
//      while (headA!=null){
//
//        if(a<=b && headA != headB) {
//          headB = headB.next;
//        }else if(a<=b && headA == headB){
//          return headA;
//        }
//        headA = headA.next;
//        a--;
//      }
//    }else{
//      while (headB!=null){
//
//        if(b<=a && headA != headB) {
//          headA = headA.next;
//        }else if(b<=a && headA == headB){
//          return headB;
//        }
//        headB = headB.next;
//        b--;
//      }
//    }
//    return null;
//  }

  static class ListNode {
    int val;
    ListNode next;

    ListNode(int x) {
      val = x;
      next = null;
    }
  }
}
