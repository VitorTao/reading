package algorithm;

public class SearchRange {

  public static int first(int[] nums, int target){
    int left = 0;
    int right = nums.length-1;
    while(left <= right){
      int mid = left + (right-left)/2;
      if(nums[mid] >= target){
        right = mid-1;
      }else if(nums[mid] < target){
        left = mid+1;
      }
    }
    if(nums[left] != target){
      left = -1;
    }
    return left;
  }
  public static int last(int[] nums, int target){
    int left = 0;
    int right = nums.length-1;
    while(left <= right){
      int mid = left + (right-left)/2;
      if(nums[mid] > target){
        right = mid-1;
      }else if(nums[mid] <= target){
        left = mid+1;
      }
    }
    if(nums[right] != target){
      right = -1;
    }
    return right;
  }

  public static void main(String[] args) {
    int target = 6;
    int[] nums = new int[]{5,7,7,8,8,10};
    int s = first(nums,target);
    int e = last(nums,target);
  }
}
